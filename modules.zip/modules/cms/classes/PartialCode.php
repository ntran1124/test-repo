<?php namespace Cms\Classes;

/**
 * Parent class for PHP classes created for partial PHP sections.
 *
 * @package october\cms
 * @author Alexey Bobkov, Samuel Georges
 */
class PartialCode extends CodeBase
{
}
