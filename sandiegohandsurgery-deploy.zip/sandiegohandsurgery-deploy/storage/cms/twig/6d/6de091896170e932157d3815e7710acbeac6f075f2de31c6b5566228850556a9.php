<?php

/* /Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/four-main-conditions2.htm */
class __TwigTemplate_89ffaaa66c4a6ab41da7a8a9a16884e27f43ca83455a2f7d55f1a1481e33e764 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"container\">
            <div class=\"col-xs-12 col-sm-6 col-md-3 col-lg-3\">
                <div class=\"gradient\">
                    <h4 class=\"contrast-h4 text-center\">Carpal Tunnel Syndrome</h4>
                    <div class=\"no-hover\">
                        <a href=\"common-conditions/carpal-tunnel-syndrome/index.html\"><img src=\"";
        // line 6
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/carpal-tunnel-syndrome2.png");
        echo "\" class=\"center-block img-circle img-responsive\"/></a>
                    </div><!--end no hover-->
                    <div class=\"hover\">
                        <p>Do you have pressure on your wrists? Many people have symptoms of Carpal Tunnel Syndrome without knowing it. Find out how the condition is caused and what treatment you’ll receive from Atlanta Hand Specialists for Carpal Tunnel Syndrome.</p>
                        <a href=\"common-conditions/carpal-tunnel-syndrome/index.html\" class=\"gray-btn\">Learn More</a>
                    </div><!--end hover-->
                </div><!--end gradient-->
            </div><!--end column-->

            <div class=\"col-xs-12 col-sm-6 col-md-3 col-lg-3\">
                <div class=\"gradient\">
                    <h4 class=\"contrast-h4 text-center\">Wrist & Hand Fracture</h4>
                    <div class=\"no-hover\">
                        <a href=\"common-conditions/wrist-fracture/index.html\"><img src=\"";
        // line 19
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/wrist-hand2.png");
        echo "\" class=\"center-block img-circle img-responsive\"/></a>
                    </div><!--end no hover-->
                    <div class=\"hover\">
                        <p>If you have shooting pain in your hand or wrist, you may have a wrist or hand fracture. Fracturing, or breaking, the bones in the wrist or hand is extremely easy because of their size and structure. Read on to learn how wrist and hand fractures are treated by Dr. Patel and the Atlanta Hand Specialists.</p>
                        <a href=\"common-conditions/hand-fractures/index.html\" class=\"gray-btn\">Learn More</a>
                        </div><!--end hover-->
                </div><!--end gradient-->
            </div><!--end colum<n-->

            <div class=\"col-xs-12 col-sm-6 col-md-3 col-lg-3\">
                <div class=\"gradient\">
                    <h4 class=\"contrast-h4 text-center\">Trigger Finger</h4>
                    <div class=\"no-hover\">
                        <a href=\"common-conditions/trigger-finger/index.html\"><img src=\"";
        // line 32
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/trigger-finger2.png");
        echo "\" class=\"center-block img-circle img-responsive\"/></a>
                    </div><!--end no hover-->
                    <div class=\"hover\">
                        <p>Trigger finger is caused by stressing the tendons and getting your thumb or finger stuck in the bent position. Inflammation and localized pressure are common signs for trigger finger. Seek treatment from the Atlanta Hand Specialists about trigger finger and your treatment options available.</p>
                        <a href=\"common-conditions/trigger-finger/index.html\" class=\"gray-btn\">Learn More</a>
                        </div><!--end hover-->
                </div><!--end gradient-->
            </div><!--end column-->

            <div class=\"col-xs-12 col-sm-6 col-md-3 col-lg-3\">
                <div class=\"gradient\">
                    <h4 class=\"contrast-h4 text-center\">Ganglion Cyst</h4>
                    <div class=\"no-hover\">
                        <a href=\"common-conditions/ganglion-cysts/index.html\"><img src=\"";
        // line 45
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/ganglion-cyst2.png");
        echo "\" class=\"center-block img-circle img-responsive\"/></a>
                    </div><!--end no hover-->
                    <div class=\"hover\">
                        <p>Tender lumps found on the hand or wrist can be a cyst. Ganglion Cysts are commonly filled with fluid, and form because of tendon or joint irritation. Find out more about how Ganglion Cysts are treated by the specialists at Atlanta Hand Specialist.</p>
                        <a href=\"common-conditions/ganglion-cysts/index.html\" class=\"gray-btn\">Learn More</a>
                        </div><!--end hover-->
                </div><!--end gradient-->
            </div><!--end column-->

            <div class=\"col-xs-12 col-sm-12 col-md-12 col-lg-12 text-center padding-filler\">
                <div>
                    <a href=\"common-conditions/index.html\" class=\"btn h4-btn\">More Common Conditions...</a>                    
                </div>
            </div>
</div>";
    }

    public function getTemplateName()
    {
        return "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/four-main-conditions2.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  74 => 45,  58 => 32,  42 => 19,  26 => 6,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"container\">
            <div class=\"col-xs-12 col-sm-6 col-md-3 col-lg-3\">
                <div class=\"gradient\">
                    <h4 class=\"contrast-h4 text-center\">Carpal Tunnel Syndrome</h4>
                    <div class=\"no-hover\">
                        <a href=\"common-conditions/carpal-tunnel-syndrome/index.html\"><img src=\"{{ 'assets/images/carpal-tunnel-syndrome2.png'|theme }}\" class=\"center-block img-circle img-responsive\"/></a>
                    </div><!--end no hover-->
                    <div class=\"hover\">
                        <p>Do you have pressure on your wrists? Many people have symptoms of Carpal Tunnel Syndrome without knowing it. Find out how the condition is caused and what treatment you’ll receive from Atlanta Hand Specialists for Carpal Tunnel Syndrome.</p>
                        <a href=\"common-conditions/carpal-tunnel-syndrome/index.html\" class=\"gray-btn\">Learn More</a>
                    </div><!--end hover-->
                </div><!--end gradient-->
            </div><!--end column-->

            <div class=\"col-xs-12 col-sm-6 col-md-3 col-lg-3\">
                <div class=\"gradient\">
                    <h4 class=\"contrast-h4 text-center\">Wrist & Hand Fracture</h4>
                    <div class=\"no-hover\">
                        <a href=\"common-conditions/wrist-fracture/index.html\"><img src=\"{{ 'assets/images/wrist-hand2.png'|theme }}\" class=\"center-block img-circle img-responsive\"/></a>
                    </div><!--end no hover-->
                    <div class=\"hover\">
                        <p>If you have shooting pain in your hand or wrist, you may have a wrist or hand fracture. Fracturing, or breaking, the bones in the wrist or hand is extremely easy because of their size and structure. Read on to learn how wrist and hand fractures are treated by Dr. Patel and the Atlanta Hand Specialists.</p>
                        <a href=\"common-conditions/hand-fractures/index.html\" class=\"gray-btn\">Learn More</a>
                        </div><!--end hover-->
                </div><!--end gradient-->
            </div><!--end colum<n-->

            <div class=\"col-xs-12 col-sm-6 col-md-3 col-lg-3\">
                <div class=\"gradient\">
                    <h4 class=\"contrast-h4 text-center\">Trigger Finger</h4>
                    <div class=\"no-hover\">
                        <a href=\"common-conditions/trigger-finger/index.html\"><img src=\"{{ 'assets/images/trigger-finger2.png'|theme }}\" class=\"center-block img-circle img-responsive\"/></a>
                    </div><!--end no hover-->
                    <div class=\"hover\">
                        <p>Trigger finger is caused by stressing the tendons and getting your thumb or finger stuck in the bent position. Inflammation and localized pressure are common signs for trigger finger. Seek treatment from the Atlanta Hand Specialists about trigger finger and your treatment options available.</p>
                        <a href=\"common-conditions/trigger-finger/index.html\" class=\"gray-btn\">Learn More</a>
                        </div><!--end hover-->
                </div><!--end gradient-->
            </div><!--end column-->

            <div class=\"col-xs-12 col-sm-6 col-md-3 col-lg-3\">
                <div class=\"gradient\">
                    <h4 class=\"contrast-h4 text-center\">Ganglion Cyst</h4>
                    <div class=\"no-hover\">
                        <a href=\"common-conditions/ganglion-cysts/index.html\"><img src=\"{{ 'assets/images/ganglion-cyst2.png'|theme }}\" class=\"center-block img-circle img-responsive\"/></a>
                    </div><!--end no hover-->
                    <div class=\"hover\">
                        <p>Tender lumps found on the hand or wrist can be a cyst. Ganglion Cysts are commonly filled with fluid, and form because of tendon or joint irritation. Find out more about how Ganglion Cysts are treated by the specialists at Atlanta Hand Specialist.</p>
                        <a href=\"common-conditions/ganglion-cysts/index.html\" class=\"gray-btn\">Learn More</a>
                        </div><!--end hover-->
                </div><!--end gradient-->
            </div><!--end column-->

            <div class=\"col-xs-12 col-sm-12 col-md-12 col-lg-12 text-center padding-filler\">
                <div>
                    <a href=\"common-conditions/index.html\" class=\"btn h4-btn\">More Common Conditions...</a>                    
                </div>
            </div>
</div>", "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/four-main-conditions2.htm", "");
    }
}
