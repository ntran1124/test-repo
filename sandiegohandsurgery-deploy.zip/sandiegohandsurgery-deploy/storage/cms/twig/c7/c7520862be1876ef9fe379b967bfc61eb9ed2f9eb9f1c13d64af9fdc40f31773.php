<?php

/* /Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/layouts/default2.htm */
class __TwigTemplate_2e87b549d22dffbb6ba13653477b09659cf8aa57b9fc742e0ad8a0bd81b8c817 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"utf-8\">
        <title>San Diego Hand Surgery - ";
        // line 5
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["this"] ?? null), "page", array()), "title", array()), "html", null, true);
        echo "</title>
        <meta name=\"description\" content=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["this"] ?? null), "page", array()), "meta_description", array()), "html", null, true);
        echo "\">
        <meta name=\"title\" content=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["this"] ?? null), "page", array()), "meta_title", array()), "html", null, true);
        echo "\">
        <meta name=\"author\" content=\"NT\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
        <meta name=\"generator\" content=\"NT\">
        <link rel='dns-prefetch' href='//sandiegohandsurgery.dev' />
        <link rel='dns-prefetch' href='//fonts.googleapis.com' />

        <link rel=\"icon\" type=\"image/png\" href=\"";
        // line 14
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/favicon.png");
        echo "\">
        <link href=\"";
        // line 15
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/vendor/bootstrap-3.3.7/css/bootstrap.css");
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 16
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/css/style3.css");
        echo "\" rel=\"stylesheet\">
        <link rel='stylesheet' id='google-font-css'  href='http://fonts.googleapis.com/css?family=Open+Sans%3A400italic%2C700italic%2C400%2C700&#038;ver=4.6.4' type='text/css' media='all' />
        <link rel='stylesheet' id='font-awesome-css'  href=\"";
        // line 18
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/vendor/font-awesome/css/font-awesome.css");
        echo "\" type='text/css' media='all' />

        <script type='text/javascript' src=\"";
        // line 20
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/vendor/bootstrap-3.3.7/js/jquery-3.2.1.js");
        echo "\"></script>
        <script type='text/javascript' src=\"";
        // line 21
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/vendor/bootstrap-3.3.7/js/bootstrap.js");
        echo "\"></script>
        <script type='text/javascript' src=\"";
        // line 22
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/javascript/imagesloaded.min.js");
        echo "\"></script>
        ";
        // line 23
        echo $this->env->getExtension('CMS')->assetsFunction('css');
        echo $this->env->getExtension('CMS')->displayBlock('styles');
        // line 24
        echo "    </head>
    <body>

        <!-- Header -->
        <header id=\"layout-header\">
            ";
        // line 29
        $context['__cms_partial_params'] = [];
        echo $this->env->getExtension('CMS')->partialFunction("site/header2"        , $context['__cms_partial_params']        );
        unset($context['__cms_partial_params']);
        // line 30
        echo "        </header>

        <!-- Slider section has been removed. -->

        <section id=\"menu-section\">
            ";
        // line 35
        $context['__cms_partial_params'] = [];
        echo $this->env->getExtension('CMS')->partialFunction("site/menu2"        , $context['__cms_partial_params']        );
        unset($context['__cms_partial_params']);
        // line 36
        echo "        </section>

        <section>
            <div class=\"container content\">
                <div class=\"row\">
                    <div class=\"col-xs-12 col-md-3 sidebar hidden-xs hidden-sm\">
                        <div class=\"gray-bg\">
                            ";
        // line 43
        $context['__cms_partial_params'] = [];
        echo $this->env->getExtension('CMS')->partialFunction("site/left-pane"        , $context['__cms_partial_params']        );
        unset($context['__cms_partial_params']);
        echo "\t
                        </div>
                    </div>
                    <div class=\"col-xs-12 col-md-9\">
                        <div class=\"row\">
                            <div class=\"col-xs-12 col-sm-8 col-md-9\" >
                                <section class=\"top-level-cell\" id=\"layout-content\">
                                    ";
        // line 50
        echo $this->env->getExtension('CMS')->pageFunction();
        // line 51
        echo "                                </section>
                            </div>
                            <div class=\"col-xs-12 col-sm-4 col-md-3 hidden-xs\"> \t
                                <div class=\"gray-bg\">
                                    ";
        // line 55
        $context['__cms_partial_params'] = [];
        echo $this->env->getExtension('CMS')->partialFunction("site/right-pane"        , $context['__cms_partial_params']        );
        unset($context['__cms_partial_params']);
        // line 56
        echo "                                </div>
                                <!--end gray bg-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section id=\"condition-section\">
            ";
        // line 66
        $context['__cms_partial_params'] = [];
        echo $this->env->getExtension('CMS')->partialFunction("site/four-main-conditions2"        , $context['__cms_partial_params']        );
        unset($context['__cms_partial_params']);
        // line 67
        echo "        </section>

        <!-- Footer -->
        <footer id=\"layout-footer\">
            ";
        // line 71
        $context['__cms_partial_params'] = [];
        echo $this->env->getExtension('CMS')->partialFunction("site/footer2"        , $context['__cms_partial_params']        );
        unset($context['__cms_partial_params']);
        // line 72
        echo "        </footer>
        <!-- Scripts -->
        ";
        // line 74
        echo '<script src="'. Request::getBasePath()
                .'/modules/system/assets/js/framework.js"></script>'.PHP_EOL;
        echo '<script src="'. Request::getBasePath()
                    .'/modules/system/assets/js/framework.extras.js"></script>'.PHP_EOL;
        echo '<link rel="stylesheet" property="stylesheet" href="'. Request::getBasePath()
                    .'/modules/system/assets/css/framework.extras.css">'.PHP_EOL;
        // line 75
        echo "        ";
        echo $this->env->getExtension('CMS')->assetsFunction('js');
        echo $this->env->getExtension('CMS')->displayBlock('scripts');
        // line 76
        echo "        <script src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/javascript/app.js");
        echo "\"></script>

    </body>
</html>";
    }

    public function getTemplateName()
    {
        return "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/layouts/default2.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  172 => 76,  168 => 75,  161 => 74,  157 => 72,  153 => 71,  147 => 67,  143 => 66,  131 => 56,  127 => 55,  121 => 51,  119 => 50,  107 => 43,  98 => 36,  94 => 35,  87 => 30,  83 => 29,  76 => 24,  73 => 23,  69 => 22,  65 => 21,  61 => 20,  56 => 18,  51 => 16,  47 => 15,  43 => 14,  33 => 7,  29 => 6,  25 => 5,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"utf-8\">
        <title>San Diego Hand Surgery - {{ this.page.title }}</title>
        <meta name=\"description\" content=\"{{ this.page.meta_description }}\">
        <meta name=\"title\" content=\"{{ this.page.meta_title }}\">
        <meta name=\"author\" content=\"NT\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
        <meta name=\"generator\" content=\"NT\">
        <link rel='dns-prefetch' href='//sandiegohandsurgery.dev' />
        <link rel='dns-prefetch' href='//fonts.googleapis.com' />

        <link rel=\"icon\" type=\"image/png\" href=\"{{ 'assets/images/favicon.png'|theme }}\">
        <link href=\"{{ 'assets/vendor/bootstrap-3.3.7/css/bootstrap.css'|theme }}\" rel=\"stylesheet\">
        <link href=\"{{ 'assets/css/style3.css'|theme }}\" rel=\"stylesheet\">
        <link rel='stylesheet' id='google-font-css'  href='http://fonts.googleapis.com/css?family=Open+Sans%3A400italic%2C700italic%2C400%2C700&#038;ver=4.6.4' type='text/css' media='all' />
        <link rel='stylesheet' id='font-awesome-css'  href=\"{{ 'assets/vendor/font-awesome/css/font-awesome.css'|theme }}\" type='text/css' media='all' />

        <script type='text/javascript' src=\"{{ 'assets/vendor/bootstrap-3.3.7/js/jquery-3.2.1.js'|theme }}\"></script>
        <script type='text/javascript' src=\"{{ 'assets/vendor/bootstrap-3.3.7/js/bootstrap.js'|theme }}\"></script>
        <script type='text/javascript' src=\"{{ 'assets/javascript/imagesloaded.min.js'|theme }}\"></script>
        {% styles %}
    </head>
    <body>

        <!-- Header -->
        <header id=\"layout-header\">
            {% partial 'site/header2' %}
        </header>

        <!-- Slider section has been removed. -->

        <section id=\"menu-section\">
            {% partial 'site/menu2' %}
        </section>

        <section>
            <div class=\"container content\">
                <div class=\"row\">
                    <div class=\"col-xs-12 col-md-3 sidebar hidden-xs hidden-sm\">
                        <div class=\"gray-bg\">
                            {% partial 'site/left-pane' %}\t
                        </div>
                    </div>
                    <div class=\"col-xs-12 col-md-9\">
                        <div class=\"row\">
                            <div class=\"col-xs-12 col-sm-8 col-md-9\" >
                                <section class=\"top-level-cell\" id=\"layout-content\">
                                    {% page %}
                                </section>
                            </div>
                            <div class=\"col-xs-12 col-sm-4 col-md-3 hidden-xs\"> \t
                                <div class=\"gray-bg\">
                                    {% partial 'site/right-pane' %}
                                </div>
                                <!--end gray bg-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section id=\"condition-section\">
            {% partial 'site/four-main-conditions2' %}
        </section>

        <!-- Footer -->
        <footer id=\"layout-footer\">
            {% partial 'site/footer2' %}
        </footer>
        <!-- Scripts -->
        {% framework extras %}
        {% scripts %}
        <script src=\"{{ 'assets/javascript/app.js'|theme }}\"></script>

    </body>
</html>", "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/layouts/default2.htm", "");
    }
}
