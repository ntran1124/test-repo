<?php

/* /Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/footer.htm */
class __TwigTemplate_cada5242d8bcc1c09aec9062a25d78dc46334e61401c939117bdda453336a08e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div id=\"footer\">
    <div class=\"container\">
    <section class=\"container-fluid  footer-locations\">
            <!--add container back-->
            <section class=\"col-xs-12 col-sm-6 col-md-4 text-left\">
                <h4><strong>San Diego Hand Surgery</strong></h4>
                <p><strong><a href=\"tel:(858) 457-2888\">Phone: (858) 457-2888</a><br>
                    Fax: (888) 369-3692</strong></p>
                    <p><strong>Hours of Operation</strong><br>
                        Monday - Friday, 8:30am - 4:00pm<br>
                </p>
            </section>
            <section class=\"col-xs-12 col-sm-6 col-md-4 text-left\">
                <address>
                    <a href=\"https://www.google.com/maps/dir//6610+Flanders+Dr+%23101,+San+Diego,+CA+92121/@32.9031025,-117.1834739,15.06z/data=!4m8!4m7!1m0!1m5!1m1!1s0x80dc0763b243879d:0x386b1f526614cf!2m2!1d-117.1766978!2d32.906116\" target=\"_blank\">
                    <img src=\"";
        // line 16
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/map-address.png");
        echo "\" class=\"thumbnail\">

                    </a>
                </address>
            </section>
            <section class=\"col-xs-12 col-sm-6 col-md-4 text-center\">
                6610 Flanders Dr, Suite 101</br>San Diego, CA 92121</br></br>
                <img src=\"";
        // line 23
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/asps_member_logo_color_Web2.jpg");
        echo "\">
            </section>
    </section>

        <section class=\"container-fluid row-fluid\">
            <div class=\"menu-footer-menu-with-sitemap-container\">
                <ul id=\"menu-footer-menu-with-sitemap\" class=\"menu\">
                    <li id=\"menu-item-61\" class=\"menu-item menu-item-type-post_type menu-item-object-page menu-item-61\"><a href=\"our-practice/index.html\">Our Practice</a></li>
                    <li id=\"menu-item-63\" class=\"menu-item menu-item-type-post_type menu-item-object-page menu-item-63\"><a href=\"meet-our-doctors/index.html\">Our Doctors</a></li>
                    <li id=\"menu-item-168\" class=\"menu-item menu-item-type-taxonomy menu-item-object-category menu-item-168\"><a href=\"common-conditions/index.html\">Common Conditions</a></li>
                    <li id=\"menu-item-62\" class=\"menu-item menu-item-type-post_type menu-item-object-page menu-item-62\"><a href=\"patient-information/index.html\">Patient Information</a></li>
                    <li id=\"menu-item-60\" class=\"menu-item menu-item-type-post_type menu-item-object-page menu-item-60\"><a href=\"contact-us-directions/index.html\">Contact Us</a></li>
                    <li id=\"menu-item-565\" class=\"menu-item menu-item-type-post_type menu-item-object-page menu-item-565\"><a href=\"contact-us-directions/index.html\">Locations</a></li>
                    <li id=\"menu-item-64\" class=\"menu-item menu-item-type-post_type menu-item-object-page menu-item-64\"><a href=\"sitemap/index.html\">Sitemap</a></li>
                </ul>
            </div>\t\t\t\t\t\t\t\t\t\t\t
        </section>
\t\t<!--/container\t  -->

        <section class=\"container-fluid row-fluid copyright\">
            <div class=\"col-md-2 hidden-xs hidden-sm\">
            </div>
            <div class=\"col-xs-12 col-sm-9 col-md-8 text-center\">
                <p>Copyright &copy; 2017 San Diego Hand Surgery. All rights reserved. This website is for informational purposes only and it is not inteded to be medical advice.</p>
            </div>
            <div class=\"col-xs-12  col-sm-3 col-md-2 text-right\">
                <p>Design by
                    <a href=\"http://www.nothingslikemine.com/\" target=\"_blank\">NILM</a>
                </p>
            </div>
        </section>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/footer.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  46 => 23,  36 => 16,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div id=\"footer\">
    <div class=\"container\">
    <section class=\"container-fluid  footer-locations\">
            <!--add container back-->
            <section class=\"col-xs-12 col-sm-6 col-md-4 text-left\">
                <h4><strong>San Diego Hand Surgery</strong></h4>
                <p><strong><a href=\"tel:(858) 457-2888\">Phone: (858) 457-2888</a><br>
                    Fax: (888) 369-3692</strong></p>
                    <p><strong>Hours of Operation</strong><br>
                        Monday - Friday, 8:30am - 4:00pm<br>
                </p>
            </section>
            <section class=\"col-xs-12 col-sm-6 col-md-4 text-left\">
                <address>
                    <a href=\"https://www.google.com/maps/dir//6610+Flanders+Dr+%23101,+San+Diego,+CA+92121/@32.9031025,-117.1834739,15.06z/data=!4m8!4m7!1m0!1m5!1m1!1s0x80dc0763b243879d:0x386b1f526614cf!2m2!1d-117.1766978!2d32.906116\" target=\"_blank\">
                    <img src=\"{{ 'assets/images/map-address.png'|theme }}\" class=\"thumbnail\">

                    </a>
                </address>
            </section>
            <section class=\"col-xs-12 col-sm-6 col-md-4 text-center\">
                6610 Flanders Dr, Suite 101</br>San Diego, CA 92121</br></br>
                <img src=\"{{ 'assets/images/asps_member_logo_color_Web2.jpg'|theme }}\">
            </section>
    </section>

        <section class=\"container-fluid row-fluid\">
            <div class=\"menu-footer-menu-with-sitemap-container\">
                <ul id=\"menu-footer-menu-with-sitemap\" class=\"menu\">
                    <li id=\"menu-item-61\" class=\"menu-item menu-item-type-post_type menu-item-object-page menu-item-61\"><a href=\"our-practice/index.html\">Our Practice</a></li>
                    <li id=\"menu-item-63\" class=\"menu-item menu-item-type-post_type menu-item-object-page menu-item-63\"><a href=\"meet-our-doctors/index.html\">Our Doctors</a></li>
                    <li id=\"menu-item-168\" class=\"menu-item menu-item-type-taxonomy menu-item-object-category menu-item-168\"><a href=\"common-conditions/index.html\">Common Conditions</a></li>
                    <li id=\"menu-item-62\" class=\"menu-item menu-item-type-post_type menu-item-object-page menu-item-62\"><a href=\"patient-information/index.html\">Patient Information</a></li>
                    <li id=\"menu-item-60\" class=\"menu-item menu-item-type-post_type menu-item-object-page menu-item-60\"><a href=\"contact-us-directions/index.html\">Contact Us</a></li>
                    <li id=\"menu-item-565\" class=\"menu-item menu-item-type-post_type menu-item-object-page menu-item-565\"><a href=\"contact-us-directions/index.html\">Locations</a></li>
                    <li id=\"menu-item-64\" class=\"menu-item menu-item-type-post_type menu-item-object-page menu-item-64\"><a href=\"sitemap/index.html\">Sitemap</a></li>
                </ul>
            </div>\t\t\t\t\t\t\t\t\t\t\t
        </section>
\t\t<!--/container\t  -->

        <section class=\"container-fluid row-fluid copyright\">
            <div class=\"col-md-2 hidden-xs hidden-sm\">
            </div>
            <div class=\"col-xs-12 col-sm-9 col-md-8 text-center\">
                <p>Copyright &copy; 2017 San Diego Hand Surgery. All rights reserved. This website is for informational purposes only and it is not inteded to be medical advice.</p>
            </div>
            <div class=\"col-xs-12  col-sm-3 col-md-2 text-right\">
                <p>Design by
                    <a href=\"http://www.nothingslikemine.com/\" target=\"_blank\">NILM</a>
                </p>
            </div>
        </section>
    </div>
</div>", "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/footer.htm", "");
    }
}
