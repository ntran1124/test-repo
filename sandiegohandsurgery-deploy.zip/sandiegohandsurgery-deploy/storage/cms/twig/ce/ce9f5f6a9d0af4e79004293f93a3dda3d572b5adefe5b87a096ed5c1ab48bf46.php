<?php

/* /Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/footer2.htm */
class __TwigTemplate_3628b2a6ecf3774d1c120e4a02806e0189f9231aa7de37a0d395f4729e683e72 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"footer-section\">
    <section class=\"container footer-locations\">
            <!--add container back-->
            <section class=\"col-xs-12 col-sm-6 col-md-4 col-lg-4 text-center\">
                <h4 class=\"contrast-h5\">San Diego Hand Surgery</h4>
                <p><a class=\"bottom-phone\" href=\"tel:(858) 457-2888\">Phone: (858) 457-2888</a><br>
                    Fax: (888) 369-3692</p>
                    <p><strong>Hours of Operations</strong><br>
                        Monday - Friday, 8:30am - 4:00pm</p>
            </section>
            <section class=\"col-xs-12 col-sm-6 col-md-4 col-lg-4 text-center\">
                <a href=\"https://www.google.com/maps/dir//6610+Flanders+Dr+%23101,+San+Diego,+CA+92121/@32.9031025,-117.1834739,15.06z/data=!4m8!4m7!1m0!1m5!1m1!1s0x80dc0763b243879d:0x386b1f526614cf!2m2!1d-117.1766978!2d32.906116\" target=\"_blank\">
                    <img src=\"";
        // line 13
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/map-image-lg.png");
        echo "\" class=\"footer-map-img\">
                </a>
            </section>
            <section class=\"col-xs-12 col-sm-12 col-md-4 col-lg-4 text-center\">
                <div class=\"visible-xs visible-sm\">
                    <br>
                </div>
                <h4 class=\"contrast-h5\">Sorrento Valley Location</h4>
                6610 Flanders Dr, Suite 101</br>San Diego, CA 92121
                </br></br>
                <img src=\"";
        // line 23
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/asps_member_logo_color_Web2.jpg");
        echo "\">
            </section>
    </section>

    <section class=\"container\">
        <div class=\"menu-footer-menu-with-sitemap-container\">
            <ul id=\"menu-footer-menu-with-sitemap\" class=\"menu smaller-size\">
                <li class=\"menu-item\"><a class=\"footer-link\" href=\"our-practice\">Our Practice</a></li>
                <li class=\"menu-item\"><a class=\"footer-link\" href=\"dr-nguyen\">Doctor & Staff</a></li>
                <li class=\"menu-item\"><a class=\"footer-link\" href=\"innovative-surgery-center\">Innovation Surgery Center</a></li>
                <li class=\"menu-item\"><a class=\"footer-link\" href=\"common-condition\">Common Conditions</a></li>
                <li class=\"menu-item\"><a class=\"footer-link\" href=\"patient-information\">Patient Information</a></li>
                <li class=\"menu-item\"><a class=\"footer-link\" href=\"contact-us\">Contact Us</a></li>
            </ul>
        </div>\t\t\t\t\t\t\t\t\t\t\t
    </section>
    <!--/container\t  -->

    <section class=\"container c-right\">
        <div class=\"col-md-2 hidden-xs hidden-sm\">
        </div>
        <div class=\"col-xs-12 col-sm-12 col-md-12 text-center\">
            <p>Copyright &copy; 2017 San Diego Hand Surgery. All rights reserved. This website is for informational purposes only and it is not inteded to be medical advice.</p>
        </div>
        <div class=\"col-xs-12  col-sm-12 col-md-12 text-right\">
            <p>Designed by
                <a class=\"c-right\" href=\"http://www.nothingslikemine.com/\" target=\"_blank\">NILM</a>
            </p>
        </div>
    </section>
</div>";
    }

    public function getTemplateName()
    {
        return "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/footer2.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  46 => 23,  33 => 13,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"footer-section\">
    <section class=\"container footer-locations\">
            <!--add container back-->
            <section class=\"col-xs-12 col-sm-6 col-md-4 col-lg-4 text-center\">
                <h4 class=\"contrast-h5\">San Diego Hand Surgery</h4>
                <p><a class=\"bottom-phone\" href=\"tel:(858) 457-2888\">Phone: (858) 457-2888</a><br>
                    Fax: (888) 369-3692</p>
                    <p><strong>Hours of Operations</strong><br>
                        Monday - Friday, 8:30am - 4:00pm</p>
            </section>
            <section class=\"col-xs-12 col-sm-6 col-md-4 col-lg-4 text-center\">
                <a href=\"https://www.google.com/maps/dir//6610+Flanders+Dr+%23101,+San+Diego,+CA+92121/@32.9031025,-117.1834739,15.06z/data=!4m8!4m7!1m0!1m5!1m1!1s0x80dc0763b243879d:0x386b1f526614cf!2m2!1d-117.1766978!2d32.906116\" target=\"_blank\">
                    <img src=\"{{ 'assets/images/map-image-lg.png'|theme }}\" class=\"footer-map-img\">
                </a>
            </section>
            <section class=\"col-xs-12 col-sm-12 col-md-4 col-lg-4 text-center\">
                <div class=\"visible-xs visible-sm\">
                    <br>
                </div>
                <h4 class=\"contrast-h5\">Sorrento Valley Location</h4>
                6610 Flanders Dr, Suite 101</br>San Diego, CA 92121
                </br></br>
                <img src=\"{{ 'assets/images/asps_member_logo_color_Web2.jpg'|theme }}\">
            </section>
    </section>

    <section class=\"container\">
        <div class=\"menu-footer-menu-with-sitemap-container\">
            <ul id=\"menu-footer-menu-with-sitemap\" class=\"menu smaller-size\">
                <li class=\"menu-item\"><a class=\"footer-link\" href=\"our-practice\">Our Practice</a></li>
                <li class=\"menu-item\"><a class=\"footer-link\" href=\"dr-nguyen\">Doctor & Staff</a></li>
                <li class=\"menu-item\"><a class=\"footer-link\" href=\"innovative-surgery-center\">Innovation Surgery Center</a></li>
                <li class=\"menu-item\"><a class=\"footer-link\" href=\"common-condition\">Common Conditions</a></li>
                <li class=\"menu-item\"><a class=\"footer-link\" href=\"patient-information\">Patient Information</a></li>
                <li class=\"menu-item\"><a class=\"footer-link\" href=\"contact-us\">Contact Us</a></li>
            </ul>
        </div>\t\t\t\t\t\t\t\t\t\t\t
    </section>
    <!--/container\t  -->

    <section class=\"container c-right\">
        <div class=\"col-md-2 hidden-xs hidden-sm\">
        </div>
        <div class=\"col-xs-12 col-sm-12 col-md-12 text-center\">
            <p>Copyright &copy; 2017 San Diego Hand Surgery. All rights reserved. This website is for informational purposes only and it is not inteded to be medical advice.</p>
        </div>
        <div class=\"col-xs-12  col-sm-12 col-md-12 text-right\">
            <p>Designed by
                <a class=\"c-right\" href=\"http://www.nothingslikemine.com/\" target=\"_blank\">NILM</a>
            </p>
        </div>
    </section>
</div>", "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/footer2.htm", "");
    }
}
