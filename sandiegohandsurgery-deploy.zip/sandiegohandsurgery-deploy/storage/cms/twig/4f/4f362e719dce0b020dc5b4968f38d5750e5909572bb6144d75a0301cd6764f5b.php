<?php

/* /Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/right-pane.htm */
class __TwigTemplate_6ba877c59ee6236ff0f9272e7ea403e3cc28dbbc5fffd2b54509d50585ea0235 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<section class=\"text-center\">
                        <a class=\"h3-link\" href=\"https://13075.portal.athenahealth.com/\" target=\"_blank\"><h4>Same Day Appointment Available</h4></a>
                        <br>
                        <a class=\"right-pane-phone\" href=\"tel:8584572888\"><span class=\"glyphicon glyphicon-earphone\"></span> (858) 457-2888</a>
                    </section>
                    <hr>
                    <section class=\"text-center\">
                        <h4>Hours of Service</h4>
                        <p>Monday - Friday, 8:30am - 4:00pm</p>
                    </section>
                    <hr>
                    <section class=\"text-center\">
                        <img src=\"";
        // line 13
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/patient-info.jpg");
        echo "\" title=\"Patient Information\" class=\"img-responsive center-block\" />
                        </br>
                        <a class=\"pane-link\" href=\"patient-information/index.html\">Patient Information</a>
                    </section>
                    <hr>
                    <section class=\"text-center\">
                        <a class=\"pane-link\" href=\"https://www.facebook.com/\" target=\"_blank\"><span class=\"glyphicon icon-facebook\"></span> Follow Us on Facebook</a>
                    </section>";
    }

    public function getTemplateName()
    {
        return "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/right-pane.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  33 => 13,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<section class=\"text-center\">
                        <a class=\"h3-link\" href=\"https://13075.portal.athenahealth.com/\" target=\"_blank\"><h4>Same Day Appointment Available</h4></a>
                        <br>
                        <a class=\"right-pane-phone\" href=\"tel:8584572888\"><span class=\"glyphicon glyphicon-earphone\"></span> (858) 457-2888</a>
                    </section>
                    <hr>
                    <section class=\"text-center\">
                        <h4>Hours of Service</h4>
                        <p>Monday - Friday, 8:30am - 4:00pm</p>
                    </section>
                    <hr>
                    <section class=\"text-center\">
                        <img src=\"{{ 'assets/images/patient-info.jpg'|theme }}\" title=\"Patient Information\" class=\"img-responsive center-block\" />
                        </br>
                        <a class=\"pane-link\" href=\"patient-information/index.html\">Patient Information</a>
                    </section>
                    <hr>
                    <section class=\"text-center\">
                        <a class=\"pane-link\" href=\"https://www.facebook.com/\" target=\"_blank\"><span class=\"glyphicon icon-facebook\"></span> Follow Us on Facebook</a>
                    </section>", "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/right-pane.htm", "");
    }
}
