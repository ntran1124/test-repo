<?php

/* /Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/pages/dr-nguyen.htm */
class __TwigTemplate_681d8004f450b783068992f86a2af273020056ee3d8a80a7ec84be53a37e394b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"container\">
<div class=\"col-xs-12 col-sm-12 col-md-5\">
    <div class=\"page-header\">
        <h2>About the Doctor...<small></small></h2>
    </div>
    <p>
        Dr. Khang T. Nguyen is a Board Certified Plastic Surgeon with a special interest in Hand Surgery. Dr. Nguyen’s practice offers a full scope of plastic, reconstructive, and hand procedures.  He has particular expertise diagnosing and treating traumatic facial and hand injuries as well as performing microvascular procedures.  In addition to performing reconstructive breast surgery, he treats common hand conditions such as trigger fingers, carpal tunnel syndrome, cubital tunnel syndrome, ganglion cysts, tendon lacerations, fractures, and hand infections.  
    </p>
    <p>
        Dr. Nguyen completed his undergraduate education with a distinction of <em>Magna Cum Laude</em> at the University of Florida.  He earned his medical degree at the University Of Florida College Of Medicine with high honors.  He successfully completed the five-year training program in General Surgery at Spartanburg Regional Healthcare System in South Carolina.  Following residency training, He pursued a Plastic & Reconstructive Surgery fellowship at the University of California San Diego.  During his two- year fellowship, Dr. Nguyen presented his research at several state, national, and international meetings, including the California Society of Plastic Surgeons (CSPS), American Society of Plastic Surgery (ASPS), and the International Consortium of Aesthetic Plastic Surgeons (ICAPS).  Dr. Nguyen has published his research in <em>Clinics of Plastic Surgery</em> and <em>The American Surgeon</em>.  
    </p>
    <p>
        Dr. Nguyen has been in private practice in San Diego since 2008.  He currently holds active medical staff privileges at Sharp Memorial, Scripps Memorial, and Scripps Encinitas Hospitals.  Dr. Nguyen performs his surgeries both at the hospitals and at an accredited Ambulatory Surgery Center.  He performs his outpatient surgeries at Innovative Surgery Center in Sorrento Valley.  Dr. Nguyen’s patients value the center’s convenience, its relaxing pre and post-op facilities, and the concierge service model that provides more personalized, private care than possible in big hospital settings.    
    </p>

</div>
</div>";
    }

    public function getTemplateName()
    {
        return "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/pages/dr-nguyen.htm";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"container\">
<div class=\"col-xs-12 col-sm-12 col-md-5\">
    <div class=\"page-header\">
        <h2>About the Doctor...<small></small></h2>
    </div>
    <p>
        Dr. Khang T. Nguyen is a Board Certified Plastic Surgeon with a special interest in Hand Surgery. Dr. Nguyen’s practice offers a full scope of plastic, reconstructive, and hand procedures.  He has particular expertise diagnosing and treating traumatic facial and hand injuries as well as performing microvascular procedures.  In addition to performing reconstructive breast surgery, he treats common hand conditions such as trigger fingers, carpal tunnel syndrome, cubital tunnel syndrome, ganglion cysts, tendon lacerations, fractures, and hand infections.  
    </p>
    <p>
        Dr. Nguyen completed his undergraduate education with a distinction of <em>Magna Cum Laude</em> at the University of Florida.  He earned his medical degree at the University Of Florida College Of Medicine with high honors.  He successfully completed the five-year training program in General Surgery at Spartanburg Regional Healthcare System in South Carolina.  Following residency training, He pursued a Plastic & Reconstructive Surgery fellowship at the University of California San Diego.  During his two- year fellowship, Dr. Nguyen presented his research at several state, national, and international meetings, including the California Society of Plastic Surgeons (CSPS), American Society of Plastic Surgery (ASPS), and the International Consortium of Aesthetic Plastic Surgeons (ICAPS).  Dr. Nguyen has published his research in <em>Clinics of Plastic Surgery</em> and <em>The American Surgeon</em>.  
    </p>
    <p>
        Dr. Nguyen has been in private practice in San Diego since 2008.  He currently holds active medical staff privileges at Sharp Memorial, Scripps Memorial, and Scripps Encinitas Hospitals.  Dr. Nguyen performs his surgeries both at the hospitals and at an accredited Ambulatory Surgery Center.  He performs his outpatient surgeries at Innovative Surgery Center in Sorrento Valley.  Dr. Nguyen’s patients value the center’s convenience, its relaxing pre and post-op facilities, and the concierge service model that provides more personalized, private care than possible in big hospital settings.    
    </p>

</div>
</div>", "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/pages/dr-nguyen.htm", "");
    }
}
