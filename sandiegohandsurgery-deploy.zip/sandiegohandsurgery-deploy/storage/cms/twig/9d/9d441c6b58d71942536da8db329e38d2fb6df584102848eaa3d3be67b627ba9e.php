<?php

/* /Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/pages/common-conditions.htm */
class __TwigTemplate_9f929f5219dedb2d380a73969dd66cf5eb8d4433a86cfebcd06585468fb020d3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<section class=\"col-sx-12 col-sm-12 col-md-12 common-cat-list\">
\t\t\t\t\t<h3>Common Conditions</h3>
\t\t\t\t\t<hr>
\t\t\t\t</section>

\t\t\t\t<section class=\"col-sx-12 col-sm-12 col-md-6 common-cat-list\">
\t\t\t\t\t<h4>Hand</h4>
\t\t\t\t\t<div class=\"img-crop\">
\t\t\t\t\t\t<img src=\"";
        // line 9
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/hand2.jpg");
        echo "\" class=\"img-responsive\" />
\t\t\t\t\t</div>
\t\t\t\t\t<ul class=\"cond-list\">
\t\t\t\t\t\t<li><a href=\"carpal-tunnel-syndrome\">Carpal Tunnel</a></li>
\t\t\t\t\t\t<li><a href=\"hand-fractures\">Hand Fractures</a></li>
\t\t\t\t\t\t<li><a href=\"osteoarthritis-of-the-hand\">Arthritis: Osteoarthritis</a></li>
\t\t\t\t\t\t<li><a href=\"hand-tumors\">Hand Tumors</a></li>
\t\t\t\t\t</ul>
\t\t\t\t\t<p class=\"text-right\"><small><a href=\"hand\">View More <i class=\"fa fa-angle-right\"></i></a></small>
\t\t\t\t\t</p>
\t\t\t\t</section>
\t\t\t\t
\t\t\t\t<section class=\"col-sx-12 col-sm-12 col-md-6 common-cat-list\">
\t\t\t\t\t<h4>Fingers</h4>
\t\t\t\t\t<div class=\"img-crop\">
\t\t\t\t\t\t<img src=\"";
        // line 24
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/fingers2.jpg");
        echo "\" class=\"img-responsive\" />
\t\t\t\t\t</div>
\t\t\t\t\t<ul class=\"cond-list\">
\t\t\t\t\t\t<li><a href=\"trigger-finger\">Trigger Finger</a></li>
\t\t\t\t\t\t<li><a href=\"numbness-and-tingling\">Numbness and Tingling</a></li>
\t\t\t\t\t\t<li><a href=\"fingertip-injuries\">Fintertip Injuries</a></li>
\t\t\t\t\t\t<li><a href=\"flexor-tendon-injuries\">Flexor Tendon Injuries</a></li>
\t\t\t\t\t</ul>
\t\t\t\t\t<p class=\"text-right\"><small><a href=\"fingers\">View More <i class=\"fa fa-angle-right\"></i></a></small>
\t\t\t\t\t</p>
\t\t\t\t</section>
\t\t\t\t<section class=\"col-sx-12 col-sm-12 col-md-6 common-cat-list\">
\t\t\t\t\t<h4>Thumb</h4>
\t\t\t\t\t<div class=\"img-crop\">
\t\t\t\t\t\t<img src=\"";
        // line 38
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/thumb2.jpg");
        echo "\" class=\"img-responsive\" />
\t\t\t\t\t</div>
\t\t\t\t\t<ul class=\"cond-list\">
\t\t\t\t\t\t<li><a href=\"arthritis-at-the-base-of-the-thumb\"> Arthritis: Base of the Thumb</a></li>
\t\t\t\t\t\t<li><a href=\"thumb-sprain\">Thumb Sprain</a></li>
\t\t\t\t\t\t<li><a href=\"de-quervains-tendonitis\">de Quervain’s Tendonitis</a></li>
\t\t\t\t\t\t<li><a href=\"extensor-tendon-injuries\">Extensor Tendon Injuries</a></li>
\t\t\t\t\t</ul>
\t\t\t\t\t<p class=\"text-right\"><small><a href=\"thumb\">View More <i class=\"fa fa-angle-right\"></i></a></small>
\t\t\t\t\t</p>
\t\t\t\t</section>
\t\t\t\t
\t\t\t\t<section class=\"col-sx-12 col-sm-12 col-md-6 common-cat-list\">
\t\t\t\t\t<h4>Wrist</h4>
\t\t\t\t\t<div class=\"img-crop\">
\t\t\t\t\t\t<img src=\"";
        // line 53
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/wrist2.jpg");
        echo "\" class=\"img-responsive\" />
\t\t\t\t\t</div>
\t\t\t\t\t<ul class=\"cond-list\">
\t\t\t\t\t\t<li><a href=\"wrist-fracture\">Wrist Fractures</a></li>
\t\t\t\t\t\t<li><a href=\"ganglion-cysts\">Ganglion Cyst</a></li>
\t\t\t\t\t\t<li><a href=\"wrist-sprain\">Wrist Sprain</a></li>
\t\t\t\t\t\t<li><a href=\"scaphoid-fracture\">Scaphoid Fracture</a></li>
\t\t\t\t\t</ul>
\t\t\t\t\t<p class=\"text-right\"><small><a href=\"wrist\">View More <i class=\"fa fa-angle-right\"></i></a></small>
\t\t\t\t\t</p>
\t\t\t\t</section>
\t\t\t\t<section class=\"col-sx-12 col-sm-12 col-md-6 common-cat-list\">
\t\t\t\t\t<h4>Elbow</h4>
\t\t\t\t\t<div class=\"img-crop\">
\t\t\t\t\t\t<img src=\"";
        // line 67
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/elbow2.jpg");
        echo "\" class=\"img-responsive\" />
\t\t\t\t\t</div>
\t\t\t\t\t<ul class=\"cond-list\">
\t\t\t\t\t\t<li><a href=\"cubital-tunnel-syndrome\">Cubital Tunnel Syndrome</a></li>
\t\t\t\t\t\t<li><a href=\"lateral-epicondylitis-tennis-elbow\">Lateral Epicondylitis (Tennis Elbow)</a>
                        </li>
                        <li><a href=\"elbow-arthritis\">Elbow Arthritis</a>
                        </li>
                        <li><a href=\"elbow-pain\">Elbow Pain</a>
                        </li>
\t\t\t\t\t</ul>
\t\t\t\t\t<p class=\"text-right\"><small><a href=\"elbow\">View More <i class=\"fa fa-angle-right\"></i></a></small>
\t\t\t\t\t</p>
\t\t\t\t</section>
                
                <section class=\"col-sx-12 col-sm-12 col-md-6 common-cat-list\">
\t\t\t\t\t<h4>Joints</h4>
\t\t\t\t\t<div class=\"img-crop\">
\t\t\t\t\t\t<img src=\"";
        // line 85
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/joints2.jpg");
        echo "\" class=\"img-responsive\" />
\t\t\t\t\t</div>
\t\t\t\t\t<ul class=\"cond-list\">
\t\t\t\t\t\t<li><a href=\"joint-pain\">Joint Pain</a>
                        </li>
                        <li><a href=\"swan-neck-deformity\">Swan-Neck Deformity</a>
                        </li>
                        <li><a href=\"mallet-finger\">Mallet Finger</a>
                        </li>
                        <li><a href=\"boutonniere-deformity\">Boutonniere Finger</a>
                        </li>
\t\t\t\t\t</ul>
\t\t\t\t\t<p class=\"text-right\"><small><a href=\"joints\">View More <i class=\"fa fa-angle-right\"></i></a></small>
\t\t\t\t\t</p>
\t\t\t\t</section>
                
                
\t\t\t\t<section class=\"col-sx-12 col-sm-12 col-md-6 common-cat-list\">
\t\t\t\t\t<h4>General</h4>
\t\t\t\t\t<div class=\"img-crop\">
\t\t\t\t\t\t<img src=\"";
        // line 105
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/general2.jpg");
        echo "\" class=\"img-responsive\" />
\t\t\t\t\t</div>
\t\t\t\t\t<ul class=\"cond-list\">
\t\t\t\t\t\t<li><a href=\"dupuytrens-disease\">Dupuytren’s Disease (Viking’s Disease)</a></li>
\t\t\t\t\t\t<li><a href=\"rheumatoid-arthritis-in-the-hands\">Arthritis: Rheumatoid Arthritis</a></li>
\t\t\t\t\t\t<li><a href=\"animal-and-human-bites\">Animal and Human Bites</a></li>
\t\t\t\t\t\t<li><a href=\"finger-or-hand-amputation\">Finger or Hand Amputation</a></li>
\t\t\t\t\t</ul>
\t\t\t\t\t<p class=\"text-right\"><small><a href=\"general\">View More <i class=\"fa fa-angle-right\"></i></a></small>
\t\t\t\t\t</p>
\t\t\t\t</section>";
    }

    public function getTemplateName()
    {
        return "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/pages/common-conditions.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  143 => 105,  120 => 85,  99 => 67,  82 => 53,  64 => 38,  47 => 24,  29 => 9,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<section class=\"col-sx-12 col-sm-12 col-md-12 common-cat-list\">
\t\t\t\t\t<h3>Common Conditions</h3>
\t\t\t\t\t<hr>
\t\t\t\t</section>

\t\t\t\t<section class=\"col-sx-12 col-sm-12 col-md-6 common-cat-list\">
\t\t\t\t\t<h4>Hand</h4>
\t\t\t\t\t<div class=\"img-crop\">
\t\t\t\t\t\t<img src=\"{{ 'assets/images/hand2.jpg'|theme }}\" class=\"img-responsive\" />
\t\t\t\t\t</div>
\t\t\t\t\t<ul class=\"cond-list\">
\t\t\t\t\t\t<li><a href=\"carpal-tunnel-syndrome\">Carpal Tunnel</a></li>
\t\t\t\t\t\t<li><a href=\"hand-fractures\">Hand Fractures</a></li>
\t\t\t\t\t\t<li><a href=\"osteoarthritis-of-the-hand\">Arthritis: Osteoarthritis</a></li>
\t\t\t\t\t\t<li><a href=\"hand-tumors\">Hand Tumors</a></li>
\t\t\t\t\t</ul>
\t\t\t\t\t<p class=\"text-right\"><small><a href=\"hand\">View More <i class=\"fa fa-angle-right\"></i></a></small>
\t\t\t\t\t</p>
\t\t\t\t</section>
\t\t\t\t
\t\t\t\t<section class=\"col-sx-12 col-sm-12 col-md-6 common-cat-list\">
\t\t\t\t\t<h4>Fingers</h4>
\t\t\t\t\t<div class=\"img-crop\">
\t\t\t\t\t\t<img src=\"{{ 'assets/images/fingers2.jpg'|theme }}\" class=\"img-responsive\" />
\t\t\t\t\t</div>
\t\t\t\t\t<ul class=\"cond-list\">
\t\t\t\t\t\t<li><a href=\"trigger-finger\">Trigger Finger</a></li>
\t\t\t\t\t\t<li><a href=\"numbness-and-tingling\">Numbness and Tingling</a></li>
\t\t\t\t\t\t<li><a href=\"fingertip-injuries\">Fintertip Injuries</a></li>
\t\t\t\t\t\t<li><a href=\"flexor-tendon-injuries\">Flexor Tendon Injuries</a></li>
\t\t\t\t\t</ul>
\t\t\t\t\t<p class=\"text-right\"><small><a href=\"fingers\">View More <i class=\"fa fa-angle-right\"></i></a></small>
\t\t\t\t\t</p>
\t\t\t\t</section>
\t\t\t\t<section class=\"col-sx-12 col-sm-12 col-md-6 common-cat-list\">
\t\t\t\t\t<h4>Thumb</h4>
\t\t\t\t\t<div class=\"img-crop\">
\t\t\t\t\t\t<img src=\"{{ 'assets/images/thumb2.jpg'|theme }}\" class=\"img-responsive\" />
\t\t\t\t\t</div>
\t\t\t\t\t<ul class=\"cond-list\">
\t\t\t\t\t\t<li><a href=\"arthritis-at-the-base-of-the-thumb\"> Arthritis: Base of the Thumb</a></li>
\t\t\t\t\t\t<li><a href=\"thumb-sprain\">Thumb Sprain</a></li>
\t\t\t\t\t\t<li><a href=\"de-quervains-tendonitis\">de Quervain’s Tendonitis</a></li>
\t\t\t\t\t\t<li><a href=\"extensor-tendon-injuries\">Extensor Tendon Injuries</a></li>
\t\t\t\t\t</ul>
\t\t\t\t\t<p class=\"text-right\"><small><a href=\"thumb\">View More <i class=\"fa fa-angle-right\"></i></a></small>
\t\t\t\t\t</p>
\t\t\t\t</section>
\t\t\t\t
\t\t\t\t<section class=\"col-sx-12 col-sm-12 col-md-6 common-cat-list\">
\t\t\t\t\t<h4>Wrist</h4>
\t\t\t\t\t<div class=\"img-crop\">
\t\t\t\t\t\t<img src=\"{{ 'assets/images/wrist2.jpg'|theme }}\" class=\"img-responsive\" />
\t\t\t\t\t</div>
\t\t\t\t\t<ul class=\"cond-list\">
\t\t\t\t\t\t<li><a href=\"wrist-fracture\">Wrist Fractures</a></li>
\t\t\t\t\t\t<li><a href=\"ganglion-cysts\">Ganglion Cyst</a></li>
\t\t\t\t\t\t<li><a href=\"wrist-sprain\">Wrist Sprain</a></li>
\t\t\t\t\t\t<li><a href=\"scaphoid-fracture\">Scaphoid Fracture</a></li>
\t\t\t\t\t</ul>
\t\t\t\t\t<p class=\"text-right\"><small><a href=\"wrist\">View More <i class=\"fa fa-angle-right\"></i></a></small>
\t\t\t\t\t</p>
\t\t\t\t</section>
\t\t\t\t<section class=\"col-sx-12 col-sm-12 col-md-6 common-cat-list\">
\t\t\t\t\t<h4>Elbow</h4>
\t\t\t\t\t<div class=\"img-crop\">
\t\t\t\t\t\t<img src=\"{{ 'assets/images/elbow2.jpg'|theme }}\" class=\"img-responsive\" />
\t\t\t\t\t</div>
\t\t\t\t\t<ul class=\"cond-list\">
\t\t\t\t\t\t<li><a href=\"cubital-tunnel-syndrome\">Cubital Tunnel Syndrome</a></li>
\t\t\t\t\t\t<li><a href=\"lateral-epicondylitis-tennis-elbow\">Lateral Epicondylitis (Tennis Elbow)</a>
                        </li>
                        <li><a href=\"elbow-arthritis\">Elbow Arthritis</a>
                        </li>
                        <li><a href=\"elbow-pain\">Elbow Pain</a>
                        </li>
\t\t\t\t\t</ul>
\t\t\t\t\t<p class=\"text-right\"><small><a href=\"elbow\">View More <i class=\"fa fa-angle-right\"></i></a></small>
\t\t\t\t\t</p>
\t\t\t\t</section>
                
                <section class=\"col-sx-12 col-sm-12 col-md-6 common-cat-list\">
\t\t\t\t\t<h4>Joints</h4>
\t\t\t\t\t<div class=\"img-crop\">
\t\t\t\t\t\t<img src=\"{{ 'assets/images/joints2.jpg'|theme }}\" class=\"img-responsive\" />
\t\t\t\t\t</div>
\t\t\t\t\t<ul class=\"cond-list\">
\t\t\t\t\t\t<li><a href=\"joint-pain\">Joint Pain</a>
                        </li>
                        <li><a href=\"swan-neck-deformity\">Swan-Neck Deformity</a>
                        </li>
                        <li><a href=\"mallet-finger\">Mallet Finger</a>
                        </li>
                        <li><a href=\"boutonniere-deformity\">Boutonniere Finger</a>
                        </li>
\t\t\t\t\t</ul>
\t\t\t\t\t<p class=\"text-right\"><small><a href=\"joints\">View More <i class=\"fa fa-angle-right\"></i></a></small>
\t\t\t\t\t</p>
\t\t\t\t</section>
                
                
\t\t\t\t<section class=\"col-sx-12 col-sm-12 col-md-6 common-cat-list\">
\t\t\t\t\t<h4>General</h4>
\t\t\t\t\t<div class=\"img-crop\">
\t\t\t\t\t\t<img src=\"{{ 'assets/images/general2.jpg'|theme }}\" class=\"img-responsive\" />
\t\t\t\t\t</div>
\t\t\t\t\t<ul class=\"cond-list\">
\t\t\t\t\t\t<li><a href=\"dupuytrens-disease\">Dupuytren’s Disease (Viking’s Disease)</a></li>
\t\t\t\t\t\t<li><a href=\"rheumatoid-arthritis-in-the-hands\">Arthritis: Rheumatoid Arthritis</a></li>
\t\t\t\t\t\t<li><a href=\"animal-and-human-bites\">Animal and Human Bites</a></li>
\t\t\t\t\t\t<li><a href=\"finger-or-hand-amputation\">Finger or Hand Amputation</a></li>
\t\t\t\t\t</ul>
\t\t\t\t\t<p class=\"text-right\"><small><a href=\"general\">View More <i class=\"fa fa-angle-right\"></i></a></small>
\t\t\t\t\t</p>
\t\t\t\t</section>", "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/pages/common-conditions.htm", "");
    }
}
