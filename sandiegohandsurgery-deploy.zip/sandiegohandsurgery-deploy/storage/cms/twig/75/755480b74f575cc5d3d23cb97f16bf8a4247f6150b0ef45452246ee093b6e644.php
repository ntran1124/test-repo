<?php

/* /Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/header2.htm */
class __TwigTemplate_9bd5bd423d485f2a934f76cf23b77d08849985d754b85c56f358985a2f0da427 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!-- Nav -->
<div class=\"container\">
    <div class=\"row\">
        <div class=\"col-xs-12 col-md-5 text-center\">
            <a href=\"/\"><img class=\"logo\" src=\"";
        // line 5
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/logo_s_380x120b.png");
        echo "\" title=\"San Diego Hand Surgery - Expert Treatments For Arthritis, Injuries &amp; More\" /></a>
        </div>
        <div class=\"col-xs-12 col-md-4 text-center header-box\">
            <a class=\"header-phone\" href=\"tel:8584572888\"><span class=\"glyphicon glyphicon-earphone\"></span> (858) 457-2888</a>
        </div>
        <div class=\"col-xs-12 col-md-3 text-center header-box\">
            <a class=\"header-btn\" href=\"https://13075.portal.athenahealth.com/\" target=\"_blank\">Make an Appointment</a>
        </div>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/header2.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 5,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!-- Nav -->
<div class=\"container\">
    <div class=\"row\">
        <div class=\"col-xs-12 col-md-5 text-center\">
            <a href=\"/\"><img class=\"logo\" src=\"{{ 'assets/images/logo_s_380x120b.png'|theme }}\" title=\"San Diego Hand Surgery - Expert Treatments For Arthritis, Injuries &amp; More\" /></a>
        </div>
        <div class=\"col-xs-12 col-md-4 text-center header-box\">
            <a class=\"header-phone\" href=\"tel:8584572888\"><span class=\"glyphicon glyphicon-earphone\"></span> (858) 457-2888</a>
        </div>
        <div class=\"col-xs-12 col-md-3 text-center header-box\">
            <a class=\"header-btn\" href=\"https://13075.portal.athenahealth.com/\" target=\"_blank\">Make an Appointment</a>
        </div>
    </div>
</div>", "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/header2.htm", "");
    }
}
