<?php

/* /Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/slider.htm */
class __TwigTemplate_39fa1ed4a7e2e8124fb3132db61a20302102d9f97342b67737b9fb8f52b3a2a3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div>
            <div id=\"carousel-example-generic\" class=\"carousel slide hidden-xs\" data-ride=\"carousel\">
                <!-- Indicators -->
                <ol class=\"carousel-indicators\">
                    <li data-target=\"#carousel-example-generic\" data-slide-to=\"0\" class=\"active\"></li>
                    <li data-target=\"#carousel-example-generic\" data-slide-to=\"1\"></li>
                    <li data-target=\"#carousel-example-generic\" data-slide-to=\"2\"></li>
                    <li data-target=\"#carousel-example-generic\" data-slide-to=\"3\"></li>
                </ol>

                <!-- Wrapper for slides -->
                <div class=\"carousel-inner\" role=\"listbox\">
                                        
                    <div class=\"item active\">
                    <img src=\"";
        // line 15
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/slider/new-building1.jpg");
        echo "\" alt=\"...\">
                    </div>
                    
                    <div class=\"item\">
                    <img src=\"";
        // line 19
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/slider/the-bridge2.jpg");
        echo "\" alt=\"...\">
                    <div class=\"carousel-caption\">
                    <h3>Call the Top-Rated <br class=\"hidden-xs\">San Diego Hand Surgeon!</h3>
                    <a href=\"our-practice/index.html\" class=\"teal-btn slider-btn\">Learn More</a>
                    </div>
                    </div>
                        
                    <div class=\"item\">
                    <img src=\"";
        // line 27
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/slider/home-slider-4.jpg");
        echo "\" alt=\"...\">
                    <div class=\"carousel-caption\">
                    <h3>Compassionate Carpal <br class=\"hidden-xs\">Tunnel Treatment</h3>
                    <a href=\"common-conditions/carpal-tunnel-syndrome/index.html\" class=\"teal-btn slider-btn\">Learn More</a>
                    </div>
                    </div>
                    
                    <div class=\"item\">
                    <img src=\"";
        // line 35
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/slider/home-slider-3.jpg");
        echo "\" alt=\"...\">
                    <div class=\"carousel-caption\">
                        <h3>What Causes Tennis Elbow<br class=\"hidden-xs\"> and Who Gets It?</h3>        
                    <a href=\"common-conditions/lateral-epicondylitis-tennis-elbow/index.html\" class=\"teal-btn slider-btn\">Find Relief Today</a>
                    </div>
                    </div>
                    
                    
                </div>

                <!-- Controls -->
                <a class=\"left carousel-control\" href=\"#carousel-example-generic\" role=\"button\" data-slide=\"prev\">
                    <span class=\"glyphicon glyphicon-chevron-left\" aria-hidden=\"true\"></span>
                    <span class=\"sr-only\">Previous</span>
                </a>
                <a class=\"right carousel-control\" href=\"#carousel-example-generic\" role=\"button\" data-slide=\"next\">
                    <span class=\"glyphicon glyphicon-chevron-right\" aria-hidden=\"true\"></span>
                    <span class=\"sr-only\">Next</span>
                </a>
            </div>\t\t\t
        </div>";
    }

    public function getTemplateName()
    {
        return "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/slider.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  64 => 35,  53 => 27,  42 => 19,  35 => 15,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
            <div id=\"carousel-example-generic\" class=\"carousel slide hidden-xs\" data-ride=\"carousel\">
                <!-- Indicators -->
                <ol class=\"carousel-indicators\">
                    <li data-target=\"#carousel-example-generic\" data-slide-to=\"0\" class=\"active\"></li>
                    <li data-target=\"#carousel-example-generic\" data-slide-to=\"1\"></li>
                    <li data-target=\"#carousel-example-generic\" data-slide-to=\"2\"></li>
                    <li data-target=\"#carousel-example-generic\" data-slide-to=\"3\"></li>
                </ol>

                <!-- Wrapper for slides -->
                <div class=\"carousel-inner\" role=\"listbox\">
                                        
                    <div class=\"item active\">
                    <img src=\"{{ 'assets/slider/new-building1.jpg'|theme }}\" alt=\"...\">
                    </div>
                    
                    <div class=\"item\">
                    <img src=\"{{ 'assets/slider/the-bridge2.jpg'|theme }}\" alt=\"...\">
                    <div class=\"carousel-caption\">
                    <h3>Call the Top-Rated <br class=\"hidden-xs\">San Diego Hand Surgeon!</h3>
                    <a href=\"our-practice/index.html\" class=\"teal-btn slider-btn\">Learn More</a>
                    </div>
                    </div>
                        
                    <div class=\"item\">
                    <img src=\"{{ 'assets/slider/home-slider-4.jpg'|theme }}\" alt=\"...\">
                    <div class=\"carousel-caption\">
                    <h3>Compassionate Carpal <br class=\"hidden-xs\">Tunnel Treatment</h3>
                    <a href=\"common-conditions/carpal-tunnel-syndrome/index.html\" class=\"teal-btn slider-btn\">Learn More</a>
                    </div>
                    </div>
                    
                    <div class=\"item\">
                    <img src=\"{{ 'assets/slider/home-slider-3.jpg'|theme }}\" alt=\"...\">
                    <div class=\"carousel-caption\">
                        <h3>What Causes Tennis Elbow<br class=\"hidden-xs\"> and Who Gets It?</h3>        
                    <a href=\"common-conditions/lateral-epicondylitis-tennis-elbow/index.html\" class=\"teal-btn slider-btn\">Find Relief Today</a>
                    </div>
                    </div>
                    
                    
                </div>

                <!-- Controls -->
                <a class=\"left carousel-control\" href=\"#carousel-example-generic\" role=\"button\" data-slide=\"prev\">
                    <span class=\"glyphicon glyphicon-chevron-left\" aria-hidden=\"true\"></span>
                    <span class=\"sr-only\">Previous</span>
                </a>
                <a class=\"right carousel-control\" href=\"#carousel-example-generic\" role=\"button\" data-slide=\"next\">
                    <span class=\"glyphicon glyphicon-chevron-right\" aria-hidden=\"true\"></span>
                    <span class=\"sr-only\">Next</span>
                </a>
            </div>\t\t\t
        </div>", "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/slider.htm", "");
    }
}
