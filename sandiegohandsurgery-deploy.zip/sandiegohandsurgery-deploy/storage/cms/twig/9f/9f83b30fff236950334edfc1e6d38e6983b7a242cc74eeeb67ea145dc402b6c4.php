<?php

/* /Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/menu2.htm */
class __TwigTemplate_3c36d73f70bb34c95a5c586ead19a69c095e397862bc9c3ff5910ab065753bc6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"container\">
            <nav class=\"navbar navbar-default\" role=\"navigation\">
\t\t\t\t<div class=\"navbar-header\">
                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\"> <span class=\"sr-only\">Toggle navigation</span>Menu</button>
\t\t\t\t</div>
\t\t\t\t<div id=\"bs-example-navbar-collapse-1\" class=\"navbar-collapse collapse\">
                    <ul id=\"menu-main-nav\" class=\"nav navbar-nav\">
                        <li id=\"menu-item-30\" class=\"nav menu-item menu-item-type-post_type menu-item-object-page\"><a title=\"Our Practice\" href=\"our-practice\">2 Our Practice</a></li>
                        <li id=\"menu-item-35\" class=\"nav menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children dropdown\">
                            <a title=\"Doctor and Staff\" href=\"#\" class=\"dropdown-toggle\">Doctor & Staff <span class=\"caret\"></span></a>
                            <ul role=\"menu\" class=\" dropdown-menu\">
                                <li id=\"menu-item-56\" class=\"menu-item menu-item-type-post_type menu-item-object-page\"><a title=\"The Doctor\" href=\"dr-nguyen\">The Doctor</a></li>
                                <li id=\"menu-item-55\" class=\"menu-item menu-item-type-post_type menu-item-object-page\"><a title=\"Staff\" href=\"staff\">Staff</a></li>
                            </ul>
                        </li>
                        <li id=\"menu-item-30\" class=\"nav menu-item menu-item-type-post_type menu-item-object-page\"><a title=\"Our Practice\" href=\"innovative-surgery-center\">Innovative Surgery Center</a></li>
                        <li id=\"menu-item-169\" class=\"nav menu-item menu-item-type-taxonomy menu-item-object-category\"><a title=\"Common Conditions\" href=\"common-conditions\">Common Conditions</a></li>
                        <li id=\"menu-item-31\" class=\"nav menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children dropdown\">
                            <a title=\"Patient Information\" href=\"#\" class=\"dropdown-toggle\">Patient Information <span class=\"caret\"></span></a>
                            <ul role=\"menu\" class=\" dropdown-menu\">
                                <li id=\"menu-item-33\" class=\"menu-item menu-item-type-post_type menu-item-object-page\">
                                    <a title=\"Patient Forms &#038; Policies\" href=\"patient-forms-policies\">Patient Forms &#038; Policies</a>
                                </li>
                                <li id=\"menu-item-32\" class=\"menu-item menu-item-type-post_type menu-item-object-page\">
                                    <a title=\"Accepted Insurance\" href=\"accepted-insurance\">Accepted Insurance</a>
                                </li>
                            </ul>
                        </li>
                        <li id=\"menu-item-37\" class=\"nav menu-item menu-item-type-taxonomy menu-item-object-category\"><a title=\"Blog\" href=\"contactus\">Contact Us</a></li>
                    </ul>
                </div>\t\t\t
    \t\t</nav>
        </div>";
    }

    public function getTemplateName()
    {
        return "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/menu2.htm";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"container\">
            <nav class=\"navbar navbar-default\" role=\"navigation\">
\t\t\t\t<div class=\"navbar-header\">
                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\"> <span class=\"sr-only\">Toggle navigation</span>Menu</button>
\t\t\t\t</div>
\t\t\t\t<div id=\"bs-example-navbar-collapse-1\" class=\"navbar-collapse collapse\">
                    <ul id=\"menu-main-nav\" class=\"nav navbar-nav\">
                        <li id=\"menu-item-30\" class=\"nav menu-item menu-item-type-post_type menu-item-object-page\"><a title=\"Our Practice\" href=\"our-practice\">2 Our Practice</a></li>
                        <li id=\"menu-item-35\" class=\"nav menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children dropdown\">
                            <a title=\"Doctor and Staff\" href=\"#\" class=\"dropdown-toggle\">Doctor & Staff <span class=\"caret\"></span></a>
                            <ul role=\"menu\" class=\" dropdown-menu\">
                                <li id=\"menu-item-56\" class=\"menu-item menu-item-type-post_type menu-item-object-page\"><a title=\"The Doctor\" href=\"dr-nguyen\">The Doctor</a></li>
                                <li id=\"menu-item-55\" class=\"menu-item menu-item-type-post_type menu-item-object-page\"><a title=\"Staff\" href=\"staff\">Staff</a></li>
                            </ul>
                        </li>
                        <li id=\"menu-item-30\" class=\"nav menu-item menu-item-type-post_type menu-item-object-page\"><a title=\"Our Practice\" href=\"innovative-surgery-center\">Innovative Surgery Center</a></li>
                        <li id=\"menu-item-169\" class=\"nav menu-item menu-item-type-taxonomy menu-item-object-category\"><a title=\"Common Conditions\" href=\"common-conditions\">Common Conditions</a></li>
                        <li id=\"menu-item-31\" class=\"nav menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children dropdown\">
                            <a title=\"Patient Information\" href=\"#\" class=\"dropdown-toggle\">Patient Information <span class=\"caret\"></span></a>
                            <ul role=\"menu\" class=\" dropdown-menu\">
                                <li id=\"menu-item-33\" class=\"menu-item menu-item-type-post_type menu-item-object-page\">
                                    <a title=\"Patient Forms &#038; Policies\" href=\"patient-forms-policies\">Patient Forms &#038; Policies</a>
                                </li>
                                <li id=\"menu-item-32\" class=\"menu-item menu-item-type-post_type menu-item-object-page\">
                                    <a title=\"Accepted Insurance\" href=\"accepted-insurance\">Accepted Insurance</a>
                                </li>
                            </ul>
                        </li>
                        <li id=\"menu-item-37\" class=\"nav menu-item menu-item-type-taxonomy menu-item-object-category\"><a title=\"Blog\" href=\"contactus\">Contact Us</a></li>
                    </ul>
                </div>\t\t\t
    \t\t</nav>
        </div>", "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/menu2.htm", "");
    }
}
