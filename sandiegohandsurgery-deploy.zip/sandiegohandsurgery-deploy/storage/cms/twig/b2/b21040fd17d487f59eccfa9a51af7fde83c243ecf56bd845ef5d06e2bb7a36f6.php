<?php

/* /Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/layouts/default.htm */
class __TwigTemplate_3e17081cebdf5b9d6c961a3fd5a40fcbc1879c14bef2314eb6004c3b70bb7b25 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"utf-8\">
        <title>San Diego Hand Surgery - ";
        // line 5
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["this"] ?? null), "page", array()), "title", array()), "html", null, true);
        echo "</title>
        <meta name=\"description\" content=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["this"] ?? null), "page", array()), "meta_description", array()), "html", null, true);
        echo "\">
        <meta name=\"title\" content=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["this"] ?? null), "page", array()), "meta_title", array()), "html", null, true);
        echo "\">
        <meta name=\"author\" content=\"NT\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
        <meta name=\"generator\" content=\"NT\">
        <link rel='dns-prefetch' href='//innovativehandsurgery.dev' />
        <link rel='dns-prefetch' href='//fonts.googleapis.com' />

        <link rel=\"icon\" type=\"image/png\" href=\"";
        // line 14
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/favicon.png");
        echo "\">
        <link href=\"";
        // line 15
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/vendor/bootstrap-3.3.7/css/bootstrap.css");
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 16
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/css/style.css");
        echo "\" rel=\"stylesheet\">
        <link rel='stylesheet' id='google-font-css'  href='http://fonts.googleapis.com/css?family=Open+Sans%3A400italic%2C700italic%2C400%2C700&#038;ver=4.6.4' type='text/css' media='all' />
        <link rel='stylesheet' id='font-awesome-css'  href=\"";
        // line 18
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/vendor/font-awesome/css/font-awesome.css");
        echo "\" type='text/css' media='all' />

        <script type='text/javascript' src=\"";
        // line 20
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/vendor/bootstrap-3.3.7/js/jquery-3.2.1.js");
        echo "\"></script>
        <script type='text/javascript' src=\"";
        // line 21
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/vendor/bootstrap-3.3.7/js/bootstrap.js");
        echo "\"></script>
        <script type='text/javascript' src=\"";
        // line 22
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/javascript/imagesloaded.min.js");
        echo "\"></script>
        ";
        // line 23
        echo $this->env->getExtension('CMS')->assetsFunction('css');
        echo $this->env->getExtension('CMS')->displayBlock('styles');
        // line 24
        echo "    </head>
    <body>

        <!-- Header -->
        <header id=\"layout-header\">
            ";
        // line 29
        $context['__cms_partial_params'] = [];
        echo $this->env->getExtension('CMS')->partialFunction("site/header"        , $context['__cms_partial_params']        );
        unset($context['__cms_partial_params']);
        // line 30
        echo "        </header>

        <!-- Slider section has been removed. -->
        <section id=\"menu-section\">
            ";
        // line 34
        $context['__cms_partial_params'] = [];
        echo $this->env->getExtension('CMS')->partialFunction("site/menu"        , $context['__cms_partial_params']        );
        unset($context['__cms_partial_params']);
        // line 35
        echo "        </section>


        <section>
            <div class=\"container content\">
                <div class=\"row\">
                    <div class=\"col-xs-12 col-md-3 sidebar hidden-xs hidden-sm\">
                        <div class=\"gray-bg\">
                            ";
        // line 43
        $context['__cms_partial_params'] = [];
        echo $this->env->getExtension('CMS')->partialFunction("site/left-pane"        , $context['__cms_partial_params']        );
        unset($context['__cms_partial_params']);
        echo "\t
                        </div>
                    </div>
                    <div class=\"col-xs-12 col-md-9\">
                        <div class=\"row\">
                            <div class=\"col-xs-12 col-sm-7 col-md-8\">
                                <article class=\"welcome\">
                                    <!-- Content -->
                                    <section id=\"layout-content\">
                                        ";
        // line 52
        echo $this->env->getExtension('CMS')->pageFunction();
        // line 53
        echo "                                    </section>
                                </article>
                            </div>
                            <div class=\"col-xs-12 col-sm-5 col-md-4 hidden-xs\"> \t
                                <div class=\"gray-bg\">
                                    ";
        // line 58
        $context['__cms_partial_params'] = [];
        echo $this->env->getExtension('CMS')->partialFunction("site/right-pane"        , $context['__cms_partial_params']        );
        unset($context['__cms_partial_params']);
        // line 59
        echo "                                </div>
                                <!--end gray bg-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section id=\"condition-section\">
            ";
        // line 69
        $context['__cms_partial_params'] = [];
        echo $this->env->getExtension('CMS')->partialFunction("site/four-main-conditions"        , $context['__cms_partial_params']        );
        unset($context['__cms_partial_params']);
        // line 70
        echo "        </section>

        <!-- Footer -->
        <footer id=\"layout-footer\">
            ";
        // line 74
        $context['__cms_partial_params'] = [];
        echo $this->env->getExtension('CMS')->partialFunction("site/footer"        , $context['__cms_partial_params']        );
        unset($context['__cms_partial_params']);
        // line 75
        echo "        </footer>
        <!-- Scripts -->
        ";
        // line 77
        echo '<script src="'. Request::getBasePath()
                .'/modules/system/assets/js/framework.js"></script>'.PHP_EOL;
        echo '<script src="'. Request::getBasePath()
                    .'/modules/system/assets/js/framework.extras.js"></script>'.PHP_EOL;
        echo '<link rel="stylesheet" property="stylesheet" href="'. Request::getBasePath()
                    .'/modules/system/assets/css/framework.extras.css">'.PHP_EOL;
        // line 78
        echo "        ";
        echo $this->env->getExtension('CMS')->assetsFunction('js');
        echo $this->env->getExtension('CMS')->displayBlock('scripts');
        // line 79
        echo "        <script src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/javascript/app.js");
        echo "\"></script>

    </body>
</html>";
    }

    public function getTemplateName()
    {
        return "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/layouts/default.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  175 => 79,  171 => 78,  164 => 77,  160 => 75,  156 => 74,  150 => 70,  146 => 69,  134 => 59,  130 => 58,  123 => 53,  121 => 52,  107 => 43,  97 => 35,  93 => 34,  87 => 30,  83 => 29,  76 => 24,  73 => 23,  69 => 22,  65 => 21,  61 => 20,  56 => 18,  51 => 16,  47 => 15,  43 => 14,  33 => 7,  29 => 6,  25 => 5,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"utf-8\">
        <title>San Diego Hand Surgery - {{ this.page.title }}</title>
        <meta name=\"description\" content=\"{{ this.page.meta_description }}\">
        <meta name=\"title\" content=\"{{ this.page.meta_title }}\">
        <meta name=\"author\" content=\"NT\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
        <meta name=\"generator\" content=\"NT\">
        <link rel='dns-prefetch' href='//innovativehandsurgery.dev' />
        <link rel='dns-prefetch' href='//fonts.googleapis.com' />

        <link rel=\"icon\" type=\"image/png\" href=\"{{ 'assets/images/favicon.png'|theme }}\">
        <link href=\"{{ 'assets/vendor/bootstrap-3.3.7/css/bootstrap.css'|theme }}\" rel=\"stylesheet\">
        <link href=\"{{ 'assets/css/style.css'|theme }}\" rel=\"stylesheet\">
        <link rel='stylesheet' id='google-font-css'  href='http://fonts.googleapis.com/css?family=Open+Sans%3A400italic%2C700italic%2C400%2C700&#038;ver=4.6.4' type='text/css' media='all' />
        <link rel='stylesheet' id='font-awesome-css'  href=\"{{ 'assets/vendor/font-awesome/css/font-awesome.css'|theme }}\" type='text/css' media='all' />

        <script type='text/javascript' src=\"{{ 'assets/vendor/bootstrap-3.3.7/js/jquery-3.2.1.js'|theme }}\"></script>
        <script type='text/javascript' src=\"{{ 'assets/vendor/bootstrap-3.3.7/js/bootstrap.js'|theme }}\"></script>
        <script type='text/javascript' src=\"{{ 'assets/javascript/imagesloaded.min.js'|theme }}\"></script>
        {% styles %}
    </head>
    <body>

        <!-- Header -->
        <header id=\"layout-header\">
            {% partial 'site/header' %}
        </header>

        <!-- Slider section has been removed. -->
        <section id=\"menu-section\">
            {% partial 'site/menu' %}
        </section>


        <section>
            <div class=\"container content\">
                <div class=\"row\">
                    <div class=\"col-xs-12 col-md-3 sidebar hidden-xs hidden-sm\">
                        <div class=\"gray-bg\">
                            {% partial 'site/left-pane' %}\t
                        </div>
                    </div>
                    <div class=\"col-xs-12 col-md-9\">
                        <div class=\"row\">
                            <div class=\"col-xs-12 col-sm-7 col-md-8\">
                                <article class=\"welcome\">
                                    <!-- Content -->
                                    <section id=\"layout-content\">
                                        {% page %}
                                    </section>
                                </article>
                            </div>
                            <div class=\"col-xs-12 col-sm-5 col-md-4 hidden-xs\"> \t
                                <div class=\"gray-bg\">
                                    {% partial 'site/right-pane' %}
                                </div>
                                <!--end gray bg-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section id=\"condition-section\">
            {% partial 'site/four-main-conditions' %}
        </section>

        <!-- Footer -->
        <footer id=\"layout-footer\">
            {% partial 'site/footer' %}
        </footer>
        <!-- Scripts -->
        {% framework extras %}
        {% scripts %}
        <script src=\"{{ 'assets/javascript/app.js'|theme }}\"></script>

    </body>
</html>", "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/layouts/default.htm", "");
    }
}
