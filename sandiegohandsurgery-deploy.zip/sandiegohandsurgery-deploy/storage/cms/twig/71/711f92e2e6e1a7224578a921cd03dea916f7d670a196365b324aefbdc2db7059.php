<?php

/* /Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/pages/homepage.htm */
class __TwigTemplate_4cf830ef3fe6877bbf6dd21d28ce1aed719685e7d50faa33c7c4a8750fea13af extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"container\">
<div class=\"col-xs-12 col-sm-12 col-md-5\">
    <div class=\"page-header\">
        <h2>Welcome to San Diego Surgery Center <small></small></h2>
    </div>
    <p>
        At San Diego Surgery Center, we are committed to providing the highest standard of care for patients with Hand and Upper Extremity conditions. Our goals are to identify and treat these conditions in all age groups, to coordinate a multidisciplinary approach for treatment, and to facilitate a rapid recovery to a normal, productive lifestyle.
    </p>
    <p>
        Every patient is treated with the utmost in care and compassion. Our professional staff is dedicated to making every patient visit convenient and pleasant, while making every possible effort for your full recovery. The availability of basic radiology makes patient diagnosis prompt and eliminates any delays in preparing the treatment plan.
    </p>
    <p>
        We understand the significance of your hands in everyday life. Our hands and arms are what we use to complete the simplest of the tasks to the most complex such as playing ball with our kids, typing an email, and performing our jobs. Whether you are an existing patient or a patient to be, thank you for choosing our office for your care.
    </p>
</div>
</div>";
    }

    public function getTemplateName()
    {
        return "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/pages/homepage.htm";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"container\">
<div class=\"col-xs-12 col-sm-12 col-md-5\">
    <div class=\"page-header\">
        <h2>Welcome to San Diego Surgery Center <small></small></h2>
    </div>
    <p>
        At San Diego Surgery Center, we are committed to providing the highest standard of care for patients with Hand and Upper Extremity conditions. Our goals are to identify and treat these conditions in all age groups, to coordinate a multidisciplinary approach for treatment, and to facilitate a rapid recovery to a normal, productive lifestyle.
    </p>
    <p>
        Every patient is treated with the utmost in care and compassion. Our professional staff is dedicated to making every patient visit convenient and pleasant, while making every possible effort for your full recovery. The availability of basic radiology makes patient diagnosis prompt and eliminates any delays in preparing the treatment plan.
    </p>
    <p>
        We understand the significance of your hands in everyday life. Our hands and arms are what we use to complete the simplest of the tasks to the most complex such as playing ball with our kids, typing an email, and performing our jobs. Whether you are an existing patient or a patient to be, thank you for choosing our office for your care.
    </p>
</div>
</div>", "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/pages/homepage.htm", "");
    }
}
