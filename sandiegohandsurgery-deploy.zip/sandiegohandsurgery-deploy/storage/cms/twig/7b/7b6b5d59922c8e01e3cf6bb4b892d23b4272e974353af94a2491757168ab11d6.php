<?php

/* /Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/pages/innovative-surgery-center.htm */
class __TwigTemplate_838b29d83ed66c5ee39d6dbb9959d725ae27b43cafdf2f0f7c4de731f1573fb8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"container\">
<div class=\"col-xs-12 col-sm-12 col-md-5\">
    <div class=\"page-header\">
        <h2>Innovative Surgery Center</h2>
    </div>
    <p>Innovative Surgery Center provides patients with a safe, comfortable, and contemporary setting for outpatient surgeries.  The center is a fully equipped, self-contained surgical center operating with state of the art equipment that includes a hospital quality operating room with a dedicated and experienced nursing team trained in assisting surgeons with all types of anesthesia (local, conscious sedation, and general anesthesia). 
    </p>
    <p>Innovative Surgery Center is fully accredited by the American Association for Accreditation of Ambulatory Surgery Facilities (AAAASF), a credentialing organization for outpatient surgery centers, and has earned Medicare Deemed Status.  The center also provides post-operative care and recovery services that meet the highest level of certification.  
    </p>
</div>
</div>";
    }

    public function getTemplateName()
    {
        return "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/pages/innovative-surgery-center.htm";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"container\">
<div class=\"col-xs-12 col-sm-12 col-md-5\">
    <div class=\"page-header\">
        <h2>Innovative Surgery Center</h2>
    </div>
    <p>Innovative Surgery Center provides patients with a safe, comfortable, and contemporary setting for outpatient surgeries.  The center is a fully equipped, self-contained surgical center operating with state of the art equipment that includes a hospital quality operating room with a dedicated and experienced nursing team trained in assisting surgeons with all types of anesthesia (local, conscious sedation, and general anesthesia). 
    </p>
    <p>Innovative Surgery Center is fully accredited by the American Association for Accreditation of Ambulatory Surgery Facilities (AAAASF), a credentialing organization for outpatient surgery centers, and has earned Medicare Deemed Status.  The center also provides post-operative care and recovery services that meet the highest level of certification.  
    </p>
</div>
</div>", "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/pages/innovative-surgery-center.htm", "");
    }
}
