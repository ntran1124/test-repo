<?php

/* /Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/pages/our-practice.htm */
class __TwigTemplate_959fdc179233cff4b23e676aff8c682a36fddcab4a76bd494d48e66ca3efcb74 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div>
        <h3>Our Practice</h3>
        <hr>
    </div>
    <p>
        The physicians and staff at San Diego Hand Surgery provide innovative solutions for conditions that affect your lifestyle. No matter your age group, our team can help successfully treat any condition in your arms, hands, or fingers that deter you from living a full, active life.
    </p>
    <h3>Mission Statement</h3>
    <p>
        <em>At San Diego Hand Surgery, we are committed to providing the highest standard of care for our patients with Hand and Upper Extremity conditions.</em>
    </p>";
    }

    public function getTemplateName()
    {
        return "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/pages/our-practice.htm";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
        <h3>Our Practice</h3>
        <hr>
    </div>
    <p>
        The physicians and staff at San Diego Hand Surgery provide innovative solutions for conditions that affect your lifestyle. No matter your age group, our team can help successfully treat any condition in your arms, hands, or fingers that deter you from living a full, active life.
    </p>
    <h3>Mission Statement</h3>
    <p>
        <em>At San Diego Hand Surgery, we are committed to providing the highest standard of care for our patients with Hand and Upper Extremity conditions.</em>
    </p>", "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/pages/our-practice.htm", "");
    }
}
