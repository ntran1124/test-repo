<?php

/* /Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/left-pane.htm */
class __TwigTemplate_cf5044059c25e1b17ed97ad2b7fbb9dd3097854855f716f8d0311c8cff94637a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<section class=\"text-center\">
                        <h4>Sorrento Valley Location</h4>
                        <div>
                            <a class=\"pane-link\" href=\"https://www.google.com/maps/dir//6610+Flanders+Dr+%23101,+San+Diego,+CA+92121/@32.9031025,-117.1834739,15.06z/data=!4m8!4m7!1m0!1m5!1m1!1s0x80dc0763b243879d:0x386b1f526614cf!2m2!1d-117.1766978!2d32.906116\" target=\"_blank\">
                            6610 Flanders Dr, Suite 101</br>San Diego, CA 92121</br></a></br>
                            <div class=\"hidden-md\">
                                <a class=\"pane-link\" href=\"https://www.google.com/maps/dir//6610+Flanders+Dr+%23101,+San+Diego,+CA+92121/@32.9031025,-117.1834739,15.06z/data=!4m8!4m7!1m0!1m5!1m1!1s0x80dc0763b243879d:0x386b1f526614cf!2m2!1d-117.1766978!2d32.906116\" target=\"_blank\">
                                    <img src=\"";
        // line 8
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/map-image-lg.png");
        echo "\" class=\"map-image\">
                                </a>
                            </div>
                            <div class=\"hidden-lg\">
                                <a class=\"pane-link\" href=\"https://www.google.com/maps/dir//6610+Flanders+Dr+%23101,+San+Diego,+CA+92121/@32.9031025,-117.1834739,15.06z/data=!4m8!4m7!1m0!1m5!1m1!1s0x80dc0763b243879d:0x386b1f526614cf!2m2!1d-117.1766978!2d32.906116\" target=\"_blank\">
                                    <img src=\"";
        // line 13
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/map-image-md.png");
        echo "\" class=\"map-image\">
                                </a>
                            </div>
                        </div>
                    </section>";
    }

    public function getTemplateName()
    {
        return "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/left-pane.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  36 => 13,  28 => 8,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<section class=\"text-center\">
                        <h4>Sorrento Valley Location</h4>
                        <div>
                            <a class=\"pane-link\" href=\"https://www.google.com/maps/dir//6610+Flanders+Dr+%23101,+San+Diego,+CA+92121/@32.9031025,-117.1834739,15.06z/data=!4m8!4m7!1m0!1m5!1m1!1s0x80dc0763b243879d:0x386b1f526614cf!2m2!1d-117.1766978!2d32.906116\" target=\"_blank\">
                            6610 Flanders Dr, Suite 101</br>San Diego, CA 92121</br></a></br>
                            <div class=\"hidden-md\">
                                <a class=\"pane-link\" href=\"https://www.google.com/maps/dir//6610+Flanders+Dr+%23101,+San+Diego,+CA+92121/@32.9031025,-117.1834739,15.06z/data=!4m8!4m7!1m0!1m5!1m1!1s0x80dc0763b243879d:0x386b1f526614cf!2m2!1d-117.1766978!2d32.906116\" target=\"_blank\">
                                    <img src=\"{{ 'assets/images/map-image-lg.png'|theme }}\" class=\"map-image\">
                                </a>
                            </div>
                            <div class=\"hidden-lg\">
                                <a class=\"pane-link\" href=\"https://www.google.com/maps/dir//6610+Flanders+Dr+%23101,+San+Diego,+CA+92121/@32.9031025,-117.1834739,15.06z/data=!4m8!4m7!1m0!1m5!1m1!1s0x80dc0763b243879d:0x386b1f526614cf!2m2!1d-117.1766978!2d32.906116\" target=\"_blank\">
                                    <img src=\"{{ 'assets/images/map-image-md.png'|theme }}\" class=\"map-image\">
                                </a>
                            </div>
                        </div>
                    </section>", "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/left-pane.htm", "");
    }
}
