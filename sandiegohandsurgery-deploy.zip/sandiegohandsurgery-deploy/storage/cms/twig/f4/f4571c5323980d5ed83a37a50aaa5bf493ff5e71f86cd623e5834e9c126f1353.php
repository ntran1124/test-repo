<?php

/* /Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/pages/our-practice-saved.htm */
class __TwigTemplate_6adbb1a65ac661120fce0af5dfc1b71ea78ffcc9449f8c299ba5892d31573f2c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"container\">
<div class=\"col-xs-12 col-sm-12 col-md-5\">
    <div class=\"page-header\">
        <h2>Our Practice <small></small></h2>
    </div>
    <p>
        The physicians and staff at San Diego Hand Surgeryprovide innovative solutions for conditions that affect your lifestyle. No matter your age group, our team can help successfully treat any condition in your arms, hands, or fingers that deter you from living a full, active life.
    </p>
    <h3>Mission Statement</h3>
    <p>
        <em>At Atlanta Hand Specialist, we are committed to providing the highest standard of care for our patients with Hand and Upper Extremity conditions.</em>
    </p>
</div>
</div>";
    }

    public function getTemplateName()
    {
        return "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/pages/our-practice-saved.htm";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"container\">
<div class=\"col-xs-12 col-sm-12 col-md-5\">
    <div class=\"page-header\">
        <h2>Our Practice <small></small></h2>
    </div>
    <p>
        The physicians and staff at San Diego Hand Surgeryprovide innovative solutions for conditions that affect your lifestyle. No matter your age group, our team can help successfully treat any condition in your arms, hands, or fingers that deter you from living a full, active life.
    </p>
    <h3>Mission Statement</h3>
    <p>
        <em>At Atlanta Hand Specialist, we are committed to providing the highest standard of care for our patients with Hand and Upper Extremity conditions.</em>
    </p>
</div>
</div>", "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/pages/our-practice-saved.htm", "");
    }
}
