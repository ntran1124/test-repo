<?php

/* /Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/header.htm */
class __TwigTemplate_dfa6416a5c9ce7b1450ee23b3a739a9d8c10c8d228b5fac12e1da9745d36ff57 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!-- Nav -->
<header>
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12 col-md-5 text-center\">
                <a href=\"/\"><img src=\"";
        // line 6
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/logo_s_380x120b.png");
        echo "\" title=\"San Diego Hand Surgery - Expert Treatments For Arthritis, Injuries &amp; More\" /></a>
            </div>
            <div class=\"col-xs-12 col-md-4 text-center\">
                    <div class=\"visible-lg\"> </br></div>
                    <a href=\"tel:8584572888\"><h2><span class=\"glyphicon glyphicon-earphone\" ></span> (858) 457-2888</h2></a>
            </div>
            <div class=\"col-xs-12 col-md-3 apt-btn text-center\">
                <div class=\"visible-lg\"> </br></div>
                <button type=\"button\" class=\"purple-btn\" onClick=\"window.open('https://13075.portal.athenahealth.com/')\">Make an Appointment</button>
            </div>
       </div>
    </div>
</header>";
    }

    public function getTemplateName()
    {
        return "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/header.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  26 => 6,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!-- Nav -->
<header>
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-xs-12 col-md-5 text-center\">
                <a href=\"/\"><img src=\"{{ 'assets/images/logo_s_380x120b.png'|theme }}\" title=\"San Diego Hand Surgery - Expert Treatments For Arthritis, Injuries &amp; More\" /></a>
            </div>
            <div class=\"col-xs-12 col-md-4 text-center\">
                    <div class=\"visible-lg\"> </br></div>
                    <a href=\"tel:8584572888\"><h2><span class=\"glyphicon glyphicon-earphone\" ></span> (858) 457-2888</h2></a>
            </div>
            <div class=\"col-xs-12 col-md-3 apt-btn text-center\">
                <div class=\"visible-lg\"> </br></div>
                <button type=\"button\" class=\"purple-btn\" onClick=\"window.open('https://13075.portal.athenahealth.com/')\">Make an Appointment</button>
            </div>
       </div>
    </div>
</header>", "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/header.htm", "");
    }
}
