<?php

/* /Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/four-main-conditions.htm */
class __TwigTemplate_fb6b3d45f62f6b409a8185d1adf285c5bd03316203d1edc6a0c05a88145a3621 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"container services-cta\">
            <div class=\"col-xs-12 col-sm-6 col-md-3\">
                <div class=\"gradient\">
                    <h2>Carpal Tunnel Syndrome</h2>
                    <div class=\"no-hover\">
                        <a href=\"common-conditions/carpal-tunnel-syndrome/index.html\"><img src=\"";
        // line 6
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/carpal-tunnel-syndrome2.png");
        echo "\" class=\"center-block img-cirgle img-responsive\"/></a>
                    </div><!--end no hover-->
                    <div class=\"hover\">
                        <p>Do you have pressure on your wrists? Many people have symptoms of Carpal Tunnel Syndrome without knowing it. Find out how the condition is caused and what treatment you’ll receive from Atlanta Hand Specialists for Carpal Tunnel Syndrome.</p>
                        <a href=\"common-conditions/carpal-tunnel-syndrome/index.html\" class=\"gray-btn\">Learn More</a>
                    </div><!--end hover-->
                </div><!--end gradient-->
            </div><!--end column-->

            <div class=\"col-xs-12 col-sm-6 col-md-3\">
                <div class=\"gradient\">
                    <h2>Wrist & Hand Fracture</h2>
                    <div class=\"no-hover\">
                        <a href=\"common-conditions/wrist-fracture/index.html\"><img src=\"";
        // line 19
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/wrist-hand2.png");
        echo "\" class=\"center-block img-cirgle img-responsive\"/></a>
                    </div><!--end no hover-->
                    <div class=\"hover\">
                        <p>If you have shooting pain in your hand or wrist, you may have a wrist or hand fracture. Fracturing, or breaking, the bones in the wrist or hand is extremely easy because of their size and structure. Read on to learn how wrist and hand fractures are treated by Dr. Patel and the Atlanta Hand Specialists.</p>
                        <a href=\"common-conditions/hand-fractures/index.html\" class=\"gray-btn\">Learn More</a>
                        </div><!--end hover-->
                </div><!--end gradient-->
            </div><!--end column-->

            <div class=\"col-xs-12 col-sm-6 col-md-3\">
                <div class=\"gradient\">
                    <h2>Trigger Finger</h2>
                    <div class=\"no-hover\">
                        <a href=\"common-conditions/trigger-finger/index.html\"><img src=\"";
        // line 32
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/trigger-finger2.png");
        echo "\" class=\"center-block img-cirgle img-responsive\"/></a>
                    </div><!--end no hover-->
                    <div class=\"hover\">
                        <p>Trigger finger is caused by stressing the tendons and getting your thumb or finger stuck in the bent position. Inflammation and localized pressure are common signs for trigger finger. Seek treatment from the Atlanta Hand Specialists about trigger finger and your treatment options available.</p>
                        <a href=\"common-conditions/trigger-finger/index.html\" class=\"gray-btn\">Learn More</a>
                        </div><!--end hover-->
                </div><!--end gradient-->
            </div><!--end column-->

            <div class=\"col-xs-12 col-sm-6 col-md-3\">
                <div class=\"gradient\">
                    <h2>Ganglion Cyst</h2>
                    <div class=\"no-hover\">
                        <a href=\"common-conditions/ganglion-cysts/index.html\"><img src=\"";
        // line 45
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/ganglion-cyst2.png");
        echo "\" class=\"center-block img-cirgle img-responsive\"/></a>
                    </div><!--end no hover-->
                    <div class=\"hover\">
                        <p>Tender lumps found on the hand or wrist can be a cyst. Ganglion Cysts are commonly filled with fluid, and form because of tendon or joint irritation. Find out more about how Ganglion Cysts are treated by the specialists at Atlanta Hand Specialist.</p>
                        <a href=\"common-conditions/ganglion-cysts/index.html\" class=\"gray-btn\">Learn More</a>
                        </div><!--end hover-->
                </div><!--end gradient-->
            </div><!--end column-->

            <div class=\"col-xs-12 text-center\">
                <a href=\"common-conditions/index.html\" class=\"teal-btn\">More Common Conditions</a>
            </div>
        </div>";
    }

    public function getTemplateName()
    {
        return "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/four-main-conditions.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  74 => 45,  58 => 32,  42 => 19,  26 => 6,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"container services-cta\">
            <div class=\"col-xs-12 col-sm-6 col-md-3\">
                <div class=\"gradient\">
                    <h2>Carpal Tunnel Syndrome</h2>
                    <div class=\"no-hover\">
                        <a href=\"common-conditions/carpal-tunnel-syndrome/index.html\"><img src=\"{{ 'assets/images/carpal-tunnel-syndrome2.png'|theme }}\" class=\"center-block img-cirgle img-responsive\"/></a>
                    </div><!--end no hover-->
                    <div class=\"hover\">
                        <p>Do you have pressure on your wrists? Many people have symptoms of Carpal Tunnel Syndrome without knowing it. Find out how the condition is caused and what treatment you’ll receive from Atlanta Hand Specialists for Carpal Tunnel Syndrome.</p>
                        <a href=\"common-conditions/carpal-tunnel-syndrome/index.html\" class=\"gray-btn\">Learn More</a>
                    </div><!--end hover-->
                </div><!--end gradient-->
            </div><!--end column-->

            <div class=\"col-xs-12 col-sm-6 col-md-3\">
                <div class=\"gradient\">
                    <h2>Wrist & Hand Fracture</h2>
                    <div class=\"no-hover\">
                        <a href=\"common-conditions/wrist-fracture/index.html\"><img src=\"{{ 'assets/images/wrist-hand2.png'|theme }}\" class=\"center-block img-cirgle img-responsive\"/></a>
                    </div><!--end no hover-->
                    <div class=\"hover\">
                        <p>If you have shooting pain in your hand or wrist, you may have a wrist or hand fracture. Fracturing, or breaking, the bones in the wrist or hand is extremely easy because of their size and structure. Read on to learn how wrist and hand fractures are treated by Dr. Patel and the Atlanta Hand Specialists.</p>
                        <a href=\"common-conditions/hand-fractures/index.html\" class=\"gray-btn\">Learn More</a>
                        </div><!--end hover-->
                </div><!--end gradient-->
            </div><!--end column-->

            <div class=\"col-xs-12 col-sm-6 col-md-3\">
                <div class=\"gradient\">
                    <h2>Trigger Finger</h2>
                    <div class=\"no-hover\">
                        <a href=\"common-conditions/trigger-finger/index.html\"><img src=\"{{ 'assets/images/trigger-finger2.png'|theme }}\" class=\"center-block img-cirgle img-responsive\"/></a>
                    </div><!--end no hover-->
                    <div class=\"hover\">
                        <p>Trigger finger is caused by stressing the tendons and getting your thumb or finger stuck in the bent position. Inflammation and localized pressure are common signs for trigger finger. Seek treatment from the Atlanta Hand Specialists about trigger finger and your treatment options available.</p>
                        <a href=\"common-conditions/trigger-finger/index.html\" class=\"gray-btn\">Learn More</a>
                        </div><!--end hover-->
                </div><!--end gradient-->
            </div><!--end column-->

            <div class=\"col-xs-12 col-sm-6 col-md-3\">
                <div class=\"gradient\">
                    <h2>Ganglion Cyst</h2>
                    <div class=\"no-hover\">
                        <a href=\"common-conditions/ganglion-cysts/index.html\"><img src=\"{{ 'assets/images/ganglion-cyst2.png'|theme }}\" class=\"center-block img-cirgle img-responsive\"/></a>
                    </div><!--end no hover-->
                    <div class=\"hover\">
                        <p>Tender lumps found on the hand or wrist can be a cyst. Ganglion Cysts are commonly filled with fluid, and form because of tendon or joint irritation. Find out more about how Ganglion Cysts are treated by the specialists at Atlanta Hand Specialist.</p>
                        <a href=\"common-conditions/ganglion-cysts/index.html\" class=\"gray-btn\">Learn More</a>
                        </div><!--end hover-->
                </div><!--end gradient-->
            </div><!--end column-->

            <div class=\"col-xs-12 text-center\">
                <a href=\"common-conditions/index.html\" class=\"teal-btn\">More Common Conditions</a>
            </div>
        </div>", "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/partials/site/four-main-conditions.htm", "");
    }
}
