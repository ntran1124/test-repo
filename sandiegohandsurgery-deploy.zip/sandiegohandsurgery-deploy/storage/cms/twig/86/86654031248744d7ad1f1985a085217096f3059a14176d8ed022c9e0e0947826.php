<?php

/* /Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/layouts/default_homepage.htm */
class __TwigTemplate_4a492fc94ddc1ff2f5f6cbc3ee88b0db6b030ac3c130195e72acf41985d0365a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"utf-8\">
        <title>Innovative Hand Surgery - ";
        // line 5
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["this"] ?? null), "page", array()), "title", array()), "html", null, true);
        echo "</title>
        <meta name=\"description\" content=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["this"] ?? null), "page", array()), "meta_description", array()), "html", null, true);
        echo "\">
        <meta name=\"title\" content=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["this"] ?? null), "page", array()), "meta_title", array()), "html", null, true);
        echo "\">
        <meta name=\"author\" content=\"NT\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
        <meta name=\"generator\" content=\"NT\">
        <link rel='dns-prefetch' href='//innovativehandsurgery.dev' />
        <link rel='dns-prefetch' href='//fonts.googleapis.com' />

        <link rel=\"icon\" type=\"image/png\" href=\"";
        // line 14
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/favicon.png");
        echo "\">
        <link href=\"";
        // line 15
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/vendor/bootstrap-3.3.7/css/bootstrap.css");
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 16
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/css/style.css");
        echo "\" rel=\"stylesheet\">
        <link rel='stylesheet' id='google-font-css'  href='http://fonts.googleapis.com/css?family=Open+Sans%3A400italic%2C700italic%2C400%2C700&#038;ver=4.6.4' type='text/css' media='all' />
        <link rel='stylesheet' id='font-awesome-css'  href=\"";
        // line 18
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/vendor/font-awesome/css/font-awesome.css");
        echo "\" type='text/css' media='all' />

        <script type='text/javascript' src=\"";
        // line 20
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/vendor/bootstrap-3.3.7/js/jquery-3.2.1.js");
        echo "\"></script>
        <script type='text/javascript' src=\"";
        // line 21
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/vendor/bootstrap-3.3.7/js/bootstrap.js");
        echo "\"></script>
        <script type='text/javascript' src=\"";
        // line 22
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/javascript/imagesloaded.min.js");
        echo "\"></script>
        ";
        // line 23
        echo $this->env->getExtension('CMS')->assetsFunction('css');
        echo $this->env->getExtension('CMS')->displayBlock('styles');
        // line 24
        echo "    </head>
    <body>

        <!-- Header -->
        <header id=\"layout-header\">
            ";
        // line 29
        $context['__cms_partial_params'] = [];
        echo $this->env->getExtension('CMS')->partialFunction("site/header"        , $context['__cms_partial_params']        );
        unset($context['__cms_partial_params']);
        // line 30
        echo "        </header>

        <section id=\"slider-section\">
            ";
        // line 33
        $context['__cms_partial_params'] = [];
        echo $this->env->getExtension('CMS')->partialFunction("site/slider"        , $context['__cms_partial_params']        );
        unset($context['__cms_partial_params']);
        // line 34
        echo "        </section>

        <section id=\"menu-section\">
            ";
        // line 37
        $context['__cms_partial_params'] = [];
        echo $this->env->getExtension('CMS')->partialFunction("site/menu"        , $context['__cms_partial_params']        );
        unset($context['__cms_partial_params']);
        // line 38
        echo "        </section>

        <section class=\"container content\">
            <aside class=\"col-xs-12 col-md-3 sidebar hidden-xs hidden-sm\">
                <div class=\"gray-bg\">
                    ";
        // line 43
        $context['__cms_partial_params'] = [];
        echo $this->env->getExtension('CMS')->partialFunction("site/left-pane"        , $context['__cms_partial_params']        );
        unset($context['__cms_partial_params']);
        echo "\t\t\t\t\t\t
                </div>
            </aside>
            <section class=\"col-xs-12 col-md-9\">

                <article class=\"welcome\">
                    <aside class=\"col-xs-12 col-sm-5 col-md-4 sidebar pull-right hidden-xs hidden-sm\"> \t
                        <div class=\"gray-bg\">
                            ";
        // line 51
        $context['__cms_partial_params'] = [];
        echo $this->env->getExtension('CMS')->partialFunction("site/right-pane"        , $context['__cms_partial_params']        );
        unset($context['__cms_partial_params']);
        echo "\t\t
                        </div>
                        <!--end gray bg-->
                    </aside>
                    
                    <!-- Content -->
                    <section id=\"layout-content\">
                        ";
        // line 58
        echo $this->env->getExtension('CMS')->pageFunction();
        // line 59
        echo "                    </section>

                </article>
            </section>
        </section>

        <section id=\"condition-section\">
            ";
        // line 66
        $context['__cms_partial_params'] = [];
        echo $this->env->getExtension('CMS')->partialFunction("site/four-main-conditions"        , $context['__cms_partial_params']        );
        unset($context['__cms_partial_params']);
        // line 67
        echo "        </section>

        <!-- Footer -->
        <footer id=\"layout-footer\">
            ";
        // line 71
        $context['__cms_partial_params'] = [];
        echo $this->env->getExtension('CMS')->partialFunction("site/footer"        , $context['__cms_partial_params']        );
        unset($context['__cms_partial_params']);
        // line 72
        echo "        </footer>

        <!-- Scripts -->
        ";
        // line 75
        echo '<script src="'. Request::getBasePath()
                .'/modules/system/assets/js/framework.js"></script>'.PHP_EOL;
        echo '<script src="'. Request::getBasePath()
                    .'/modules/system/assets/js/framework.extras.js"></script>'.PHP_EOL;
        echo '<link rel="stylesheet" property="stylesheet" href="'. Request::getBasePath()
                    .'/modules/system/assets/css/framework.extras.css">'.PHP_EOL;
        // line 76
        echo "        ";
        echo $this->env->getExtension('CMS')->assetsFunction('js');
        echo $this->env->getExtension('CMS')->displayBlock('scripts');
        // line 77
        echo "        <script src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/javascript/app.js");
        echo "\"></script>
    </body>
</html>";
    }

    public function getTemplateName()
    {
        return "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/layouts/default_homepage.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  178 => 77,  174 => 76,  167 => 75,  162 => 72,  158 => 71,  152 => 67,  148 => 66,  139 => 59,  137 => 58,  125 => 51,  112 => 43,  105 => 38,  101 => 37,  96 => 34,  92 => 33,  87 => 30,  83 => 29,  76 => 24,  73 => 23,  69 => 22,  65 => 21,  61 => 20,  56 => 18,  51 => 16,  47 => 15,  43 => 14,  33 => 7,  29 => 6,  25 => 5,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"utf-8\">
        <title>Innovative Hand Surgery - {{ this.page.title }}</title>
        <meta name=\"description\" content=\"{{ this.page.meta_description }}\">
        <meta name=\"title\" content=\"{{ this.page.meta_title }}\">
        <meta name=\"author\" content=\"NT\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
        <meta name=\"generator\" content=\"NT\">
        <link rel='dns-prefetch' href='//innovativehandsurgery.dev' />
        <link rel='dns-prefetch' href='//fonts.googleapis.com' />

        <link rel=\"icon\" type=\"image/png\" href=\"{{ 'assets/images/favicon.png'|theme }}\">
        <link href=\"{{ 'assets/vendor/bootstrap-3.3.7/css/bootstrap.css'|theme }}\" rel=\"stylesheet\">
        <link href=\"{{ 'assets/css/style.css'|theme }}\" rel=\"stylesheet\">
        <link rel='stylesheet' id='google-font-css'  href='http://fonts.googleapis.com/css?family=Open+Sans%3A400italic%2C700italic%2C400%2C700&#038;ver=4.6.4' type='text/css' media='all' />
        <link rel='stylesheet' id='font-awesome-css'  href=\"{{ 'assets/vendor/font-awesome/css/font-awesome.css'|theme }}\" type='text/css' media='all' />

        <script type='text/javascript' src=\"{{ 'assets/vendor/bootstrap-3.3.7/js/jquery-3.2.1.js'|theme }}\"></script>
        <script type='text/javascript' src=\"{{ 'assets/vendor/bootstrap-3.3.7/js/bootstrap.js'|theme }}\"></script>
        <script type='text/javascript' src=\"{{ 'assets/javascript/imagesloaded.min.js'|theme }}\"></script>
        {% styles %}
    </head>
    <body>

        <!-- Header -->
        <header id=\"layout-header\">
            {% partial 'site/header' %}
        </header>

        <section id=\"slider-section\">
            {% partial 'site/slider' %}
        </section>

        <section id=\"menu-section\">
            {% partial 'site/menu' %}
        </section>

        <section class=\"container content\">
            <aside class=\"col-xs-12 col-md-3 sidebar hidden-xs hidden-sm\">
                <div class=\"gray-bg\">
                    {% partial 'site/left-pane' %}\t\t\t\t\t\t
                </div>
            </aside>
            <section class=\"col-xs-12 col-md-9\">

                <article class=\"welcome\">
                    <aside class=\"col-xs-12 col-sm-5 col-md-4 sidebar pull-right hidden-xs hidden-sm\"> \t
                        <div class=\"gray-bg\">
                            {% partial 'site/right-pane' %}\t\t
                        </div>
                        <!--end gray bg-->
                    </aside>
                    
                    <!-- Content -->
                    <section id=\"layout-content\">
                        {% page %}
                    </section>

                </article>
            </section>
        </section>

        <section id=\"condition-section\">
            {% partial 'site/four-main-conditions' %}
        </section>

        <!-- Footer -->
        <footer id=\"layout-footer\">
            {% partial 'site/footer' %}
        </footer>

        <!-- Scripts -->
        {% framework extras %}
        {% scripts %}
        <script src=\"{{ 'assets/javascript/app.js'|theme }}\"></script>
    </body>
</html>", "/Users/nguyen/Documents/dev/sandiegohandsurgery/themes/sdhs/layouts/default_homepage.htm", "");
    }
}
