<?php 
class Cms590688582f1e5980295699_cc6701fb5d99b42036bbdf7fc69447c8Class extends \Cms\Classes\PartialCode
{

}
