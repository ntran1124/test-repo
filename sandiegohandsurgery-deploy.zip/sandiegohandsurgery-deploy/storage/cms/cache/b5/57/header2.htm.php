<?php 
class Cms5906ce1fe61fd621014184_2e439746b39042abd2058371b95a69f8Class extends \Cms\Classes\PartialCode
{

}
