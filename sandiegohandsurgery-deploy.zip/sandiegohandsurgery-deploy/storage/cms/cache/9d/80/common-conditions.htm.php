<?php 
class Cms590d563cce7ae815329241_21b95b962e2ff641c2e4f36a642c69daClass extends \Cms\Classes\PageCode
{

}
