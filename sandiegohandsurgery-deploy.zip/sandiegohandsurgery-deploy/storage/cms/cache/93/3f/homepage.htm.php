<?php 
class Cms5906885807c6d774041483_92ea3cc20d3fd185bbd2a762f0fae9c0Class extends \Cms\Classes\PageCode
{

}
