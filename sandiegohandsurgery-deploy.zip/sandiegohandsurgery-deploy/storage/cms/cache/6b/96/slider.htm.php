<?php 
class Cms590688581bb00574347243_9726cc1b1de35982906fe45e37171ad9Class extends \Cms\Classes\PartialCode
{

}
