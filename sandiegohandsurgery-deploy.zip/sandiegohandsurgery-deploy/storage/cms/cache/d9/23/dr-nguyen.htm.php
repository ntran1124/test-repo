<?php 
class Cms5906d723b7b6f640153286_5ddb6ae363e390f7ed97ed5c47486a79Class extends \Cms\Classes\PageCode
{

}
