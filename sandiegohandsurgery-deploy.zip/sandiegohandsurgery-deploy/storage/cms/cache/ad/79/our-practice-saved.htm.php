<?php 
class Cms59082cd585bdb994536525_b300801cdc4623c04e1029c8092fa22fClass extends \Cms\Classes\PageCode
{

}
