<?php 
class Cms590eaf074f9a6734824304_c2af7bde35599ac16e7e2742e3dd9a0dClass extends \Cms\Classes\PartialCode
{

}
