<?php 
class Cms590d571e27da3739807431_920a8fc61625ff5190eb61a7dc8cfa0bClass extends \Cms\Classes\PageCode
{

}
