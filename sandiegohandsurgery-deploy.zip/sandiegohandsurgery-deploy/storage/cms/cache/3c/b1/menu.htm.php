<?php 
class Cms590e8e8e7dc55175172927_42af37db101b896c1e2c6512c396c47bClass extends \Cms\Classes\PartialCode
{

}
