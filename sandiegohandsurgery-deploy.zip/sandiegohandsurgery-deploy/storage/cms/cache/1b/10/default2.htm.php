<?php 
class Cms590e1aca768b4476894419_75b457ec0f9c4c35c398c82063177bb4Class extends \Cms\Classes\LayoutCode
{

}
