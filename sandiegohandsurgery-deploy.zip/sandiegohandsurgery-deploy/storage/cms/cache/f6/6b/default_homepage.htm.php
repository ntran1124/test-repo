<?php 
class Cms5906d9f31a577372736365_fbb0e7ce5481076779d62eb7832063a8Class extends \Cms\Classes\LayoutCode
{

}
