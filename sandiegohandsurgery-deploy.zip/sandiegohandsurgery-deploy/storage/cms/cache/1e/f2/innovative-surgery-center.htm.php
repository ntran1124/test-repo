<?php 
class Cms5906cf6dbf226960285421_d188973b8fa9d8cf1c00e720054ebfa6Class extends \Cms\Classes\PageCode
{

}
