<?php 
class Cms590e5a1c1114f861910526_e08c725d37dd7fe8867d3dbf753641d9Class extends \Cms\Classes\PartialCode
{

}
