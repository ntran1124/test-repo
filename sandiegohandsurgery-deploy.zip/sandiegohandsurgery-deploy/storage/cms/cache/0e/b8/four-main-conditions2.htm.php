<?php 
class Cms590e19ae0c152820229120_f4b03886b7c07a28cfc4d1c32e51c25bClass extends \Cms\Classes\PartialCode
{

}
