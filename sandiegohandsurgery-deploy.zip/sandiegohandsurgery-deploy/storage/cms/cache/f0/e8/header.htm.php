<?php 
class Cms590692158851a304663306_d4ff57432870002e7ddb9cc608f7a143Class extends \Cms\Classes\PartialCode
{

}
