<?php 
class Cms590d70698eaff336600416_3692626f1190f0142545f0b821034ea9Class extends \Cms\Classes\PartialCode
{

}
