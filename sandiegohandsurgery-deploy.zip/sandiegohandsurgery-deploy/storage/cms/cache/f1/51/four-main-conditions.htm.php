<?php 
class Cms590deaf0cd048873439792_dde5468609636874d64db31d54a93459Class extends \Cms\Classes\PartialCode
{

}
