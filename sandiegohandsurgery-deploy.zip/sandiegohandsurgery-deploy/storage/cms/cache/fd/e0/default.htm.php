<?php 
class Cms5906de455ea08083840252_f92c013691e0b1cc32a2b2bb90b6b31aClass extends \Cms\Classes\LayoutCode
{

}
