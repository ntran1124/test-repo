<?php 
class Cms590d6e8ab1118249306633_3c29d49319c80cc4c138e84c8a997f54Class extends \Cms\Classes\PartialCode
{

}
