<?php namespace TestVendor\Test\FormWidgets;

use Backend\Classes\FormWidgetBase;

class Sample extends FormWidgetBase
{
}