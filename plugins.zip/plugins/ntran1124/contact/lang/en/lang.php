<?php return [
    'plugin' => [
        'name' => 'Contact',
        'description' => ''
    ]
];