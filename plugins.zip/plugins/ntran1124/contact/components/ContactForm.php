<?php 

namespace Ntran1124\Contact\Components;

use Cms\Classes\ComponentBase;
use Input;
use Mail;
use Validator;
use Redirect;

class ContactForm extends ComponentBase
{
    public function componentDetails() {
        return [
            'name' => 'contactform',
            'description' => 'Simple contact form'
        ];
    }



    public function onSend() {
        $validator = Validator::make(
            [
                'name' => Input::get('name'), 
                'email' => Input::get('email'),
                'content' => Input::get('content')
            ],
            [
                'name' => 'required', 
                'email' => 'required|email',
                'content' => 'required'
            ]
        );

        if ($validator->fails()) {
            return Redirect::back()->withError($validator);

        } else {
            $vars = [
                'name' => Input::get('name'), 
                'email' => Input::get('email'),
                'content' => Input::get('content')
            ];

            Mail::send('ntran1124.contact::mail.message', $vars, function($message) {
                $message->to('ntran1124@gmail.com', 'Nguyen Tran');
                $message->subject('new message from contact form');
            });

            return Redirect::to('/thank-you');
        }
    }

}

?>