/*

=require builder.dataregistry.js
=require builder.index.entity.base.js
=require builder.index.entity.plugin.js
=require builder.index.entity.databasetable.js
=require builder.index.entity.model.js
=require builder.index.entity.modelform.js
=require builder.index.entity.modellist.js
=require builder.index.entity.permission.js
=require builder.index.entity.menus.js
=require builder.index.entity.version.js
=require builder.index.entity.localization.js
=require builder.index.entity.controller.js
=require builder.index.js
=require builder.localizationinput.js
=require builder.inspector.editor.localization.js
=require builder.table.processor.localization.js

*/
