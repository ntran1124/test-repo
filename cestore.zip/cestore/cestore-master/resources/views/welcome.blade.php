@extends('layouts.master')

@section('content')
<h1>Welcome to CE Store</h1>
@endsection