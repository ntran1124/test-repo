@extends('layouts.master')

@section('content')
    @include('partials.errors')
    <div class="row">
        <div class="col-md-12">
            <form action="{{ route('manufacturers.updateManufacturer') }}" method="post">
                <div class="form-group">
                    <label for="name" class="col-md-2">Name</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="name" name="name" 
                            value="{{ $manufacturer->name }}">
                    </div>
                </div>
                <div class="form-group">
                    <label for="phone" class="col-md-2">Phone Number</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="phone" name="phone"
                            value="{{ $manufacturer->phone }}">
                    </div>
                </div>
                <div class="form-group">
                    <label for="homepage" class="col-md-2">Homepage</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="homepage" name="homepage"
                            value="{{ $manufacturer->homepage }}">
                    </div>
                </div>
                {{ csrf_field() }}
                <input type="hidden" name="id" value="{{ $manufacturer->id }}">
                <div class="col-md-10 col-md-offset-2">
                    <button type="submit" class="btn btn-primary">Update</button> 
                    <a href="{{ route("manufacturers.index") }}" class="btn btn-primary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
@endsection