@extends('layouts.master')

@section('content')
    @if(Session::has('info'))
        <div class="row">
            <div class="col-md-12">
                <p class="alert alert-info">{{ Session::get('info') }}</p>
            </div>
        </div>
    @endif
    <div class="row">
        <div class="col-md-12">
            <h3>Manufacturers</h3>
        </div>
    </div>
    
    <div style="max-height:350px; overflow:scroll;">
        @foreach($manufacturers as $manufacturer)
            <div class="row">
                <div class="col-sm-1">
                    {{ $manufacturer->id }}
                </div>
                <div class="col-sm-2">
                    {{ $manufacturer->name }}
                </div>
                <div class="col-sm-2">
                    {{ $manufacturer->phone }}
                </div>
                <div class="col-sm-4">
                    {{ $manufacturer->homepage }}
                </div>
                <div class="col-sm-1">
                    <a class="link" href="{{ route('manufacturers.detail', ['id' => $manufacturer->id]) }}">Detail</a>
                </div>
                <div class="col-sm-1">
                    <a class="link" href="{{ route('manufacturers.update', ['id' => $manufacturer->id]) }}">Update</a>
                </div>
                <div class="col-sm-1">
                    <a class="link" href="{{ route('manufacturers.delete', ['id' => $manufacturer->id]) }}">Delete</a>
                </div>
            </div>
            <hr>
        @endforeach
    </div>
        <div class = row> <br> </div>
        <div class = row>
        <div class="col-md-12">
            <a class="link" href="{{ route('manufacturers.create') }}">Create a new Manufacturer</a>
            <hr>
        </div>
    </div>
@endsection