<div class = row> <br> </div>
<div class="panel panel-default">
    <div class="panel-heading">
        <h3 class="panel-title">This is a group project of SSWD course at Continued Education of San Diego, California.</h3>
    </div>
    <!--
    <div class="panel-body">
        It's cool, it's it?
    </div>
    <div class="progress">
        <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100" style="width: 10%">
            <span class="sr-only">10% Complete (danger)</span>
        </div>
    </div>
    <div class="alert alert-warning alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <strong>Warning!</strong> Need more work from team members. :-) Make it happen!!!
    </div>
    -->
</div>