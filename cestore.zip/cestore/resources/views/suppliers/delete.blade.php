@extends('layouts.master')

@section('content')
    <div class="row">
        <div class="col-md-12">
            <p class="alert alert-info">You are deleting the following supplier.
                <br>If you are sure, click Delete button.
                <br>Otherwise, click Cancel button.
            </p>
        </div>
    </div>

    <div class= row>
        <div class="col-md-12">
            <form action="{{ route('suppliers.deleteSupplier') }}" method="post">
                <div class="form-group">
                    <label for="name" class="col-md-2">Name</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="name" name="name" 
                            value="{{ $supplier->name }}" readonly>
                    </div>
                </div>
                <div class="form-group">
                    <label for="homepage" class="col-md-2">Homepage</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="homepage" name="homepage"
                            value="{{ $supplier->homepage }}" readonly>
                    </div>
                    <div class=row> <br> </div>
                </div>
                
                {{ csrf_field() }}
                <input type="hidden" name="id" value="{{ $supplier->id }}">
                <div class="col-md-10 col-md-offset-2">
                    <button type="submit" class="btn btn-primary">Delete</button> 
                    <a href="{{ route("suppliers.index") }}" class="btn btn-primary">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
@endsection