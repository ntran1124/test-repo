@extends('layouts.master')

@section('content')
    @if(Session::has('info'))
        <div class="row">
            <div class="col-md-12">
                <p class="alert alert-info">{{ Session::get('info') }}</p>
            </div>
        </div>
    @endif
    
    <div class="row">
        <div class="col-md-12">
            <h3>Suppliers</h3>
        </div>
    </div>

    <div style="max-height:350px; overflow:scroll;">
            @foreach($suppliers as $supplier)
                <div class="row">
                    <div class="col-sm-2">
                        {{ $supplier->name }}
                    </div>
                    <div class="col-sm-2">
                        {{ $supplier->contact_name }}
                    </div>
                    <div class="col-sm-2">
                        {{ $supplier->phone }}
                    </div>
                    <div class="col-sm-3">
                        {{ $supplier->homepage }}
                    </div>
                    <div class="col-sm-1">
                        <a class="link" href="{{ route('suppliers.detail', ['id' => $supplier->id]) }}">Detail</a>    
                    </div>
                    <div class="col-sm-1">
                        <a class="link" href="{{ route('suppliers.update', ['id' => $supplier->id]) }}">Update</a>
                    </div>
                    <div class="col-sm-1">
                        <a class="link" href="{{ route('suppliers.delete', ['id' => $supplier->id]) }}">Delete</a>
                    </div>
                </div>
                <hr>
            @endforeach

            <div class="row"> <br> </div>
            <div class="col-md-12">
                <a class="link" href="{{ route('suppliers.create') }}">Create a new supplier</a>
                <hr>
            </div>
    </div>


            <div class = row> <br> </div>
        </div>
    





    




@endsection