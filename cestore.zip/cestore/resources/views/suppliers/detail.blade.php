@extends('layouts.master')

@section('content')
    
    <div class="row">
        <div class="col-md-12">
             <form>
                <div class="form-group">
                    <label for="name" class="col-md-2">Name</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="name" name="name" 
                            value="{{ $supplier->name }}" readonly>
                    </div>
                </div>

                <div class="form-group">
                    <label for="is_direct_sales" class="col-md-2">Direct Sales</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="is_direct_sales" name="is_direct_sales"
                            value="{{ $supplier->is_direct_sales }}" readonly>
                    </div>
                </div>

                <div class="form-group">
                    <label for="contact_name" class="col-md-2">Contact Name</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="contact_name" name="contact_name" 
                            value="{{ $supplier->contact_name }}" readonly>
                    </div>
                </div>

                <div class="form-group">
                    <label for="contact_title" class="col-md-2">Contact Title</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="contact_title" name="contact_title" 
                            value="{{ $supplier->contact_title }}" readonly>
                    </div>
                </div>

                <div class="form-group">
                    <label for="phone" class="col-md-2">Phone Number</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="phone" name="phone"
                            value="{{ $supplier->phone }}" readonly>
                    </div>
                </div>

                <div class="form-group">
                    <label for="fax" class="col-md-2">Fax Number</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="fax" name="fax" 
                            value="{{ $supplier->fax }}" readonly>
                    </div>
                </div>

                <div class="form-group">
                    <label for="email" class="col-md-2">Email Address</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="email" name="email"
                            value="{{ $supplier->email }}" readonly>
                    </div>
                </div>

                <div class="form-group">
                    <label for="homepage" class="col-md-2">Homepage</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="homepage" name="homepage"
                            value="{{ $supplier->homepage }}" readonly>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="address" class="col-md-2">Mailing Address</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="address" name="address"
                            value="{{ $supplier->address }}" readonly>
                    </div>
                </div>

                <div class="form-group">
                    <label for="created_at" class="col-md-2">Created On</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="created_at" name="created_at"
                            value="{{ $supplier->created_at }}" readonly>
                    </div>
                </div>

                <div class="form-group">
                    <label for="updated_at" class="col-md-2">Updated On</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="updated_at" name="updated_at"
                            value="{{ $supplier->updated_at }}" readonly>
                    </div>
                </div>

                {{ csrf_field() }}
                <input type="hidden" name="id" value="{{ $supplier->id }}">
                <div class="col-md-10 col-md-offset-2">
                    <a href="{{ route('suppliers.index') }}" class="btn btn-primary">Go Back</a>
                    <a href="{{ route('suppliers.update', ['id' => $supplier->id]) }}" class="btn btn-primary">Update</a>
                </div>
            </form>
        </div>
    </div>
@endsection