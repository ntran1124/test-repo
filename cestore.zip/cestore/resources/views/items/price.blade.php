@extends('layouts.master')

@section('content')
    @if(Session::has('info'))
        <div class="row">
            <div class="col-md-12">
                <p class="alert alert-info">{{ Session::get('info') }}</p>
            </div>
        </div>
    @endif
    <div class="row">
        <div class="col-md-12">
            <h3>{{ $item->name }} - Prices</h3>
            <hr>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <table>
                <tr>
                    <td>
                        <form action="{{ route('items.priceitem') }}" method="post">
                            <div class="form-group">
                                <label for="value" class="col-md-4">Price:</label>
                                <div class="col-md-8">
                                    <input type="text" class="form-control" id="value" name="value">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="set_date" class="col-md-4">Effective date:</label>
                                <div class="col-md-8">
                                    <input type="text" class="form-control" id="set_date" name="set_date">
                                </div>
                            </div>              

                            {{ csrf_field() }}
                            <div class="col-md-8 col-md-offset-4">
                                <br>
                                <input type="hidden" id="item_id" name="item_id" value="{{ $item->id }}">
                                <button type="submit" class="btn btn-primary">Set price</button> 
                                <a href="{{ route("items.index") }}" class="btn btn-primary">Back</a>
                            </div>
                        </form>    
                    </td>
                </tr>
            </table>
        </div>
        <div class="col-md-6">
            <table class="table table-responsive">
                <tr>
                    <td><b>Price</b></td>
                    <td><b>Effective date</b></td>
                </tr>
                @foreach($prices as $price)
                <tr>
                    <td>
                        ${{ number_format($price->value, 2, '.', ',') }}
                    </td>
                    <td>
                        {{ $price->set_date }}
                    </td>
                </tr>
                @endforeach
            </table>
        </div>    
    </div>
    <div class="row">
        <div class="col-md-12">
            
            <hr>
        </div>
    </div>
@endsection