@extends('layouts.master')

@section('content')
    @include('partials.errors')
    @if(Session::has('info'))
            <div class="row">
                <div class="col-md-12">
                    <p class="alert alert-info">{{ Session::get('info') }}</p>
                </div>
            </div>
    @endif

    <div style="text-align: center"> <img src="{{$item->image_src}}" width="200px"></div>

    <h3>Please Rate This Item</h3>
    <div class="row">
        <div class="col-md-12">

            <form action="{{ route('rates') }}" method="post">
                <div class="form-group">
                    <label for="manufacturer_name" class="col-md-2">Manufacturer</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="manufacturer_name" name="manufacturer_name"
                            value="{{ $item->manufacturer->name }}" readonly="readonly">
                    </div>
                </div>                    
                                    
                <div class="form-group">
                    <label for="name" class="col-md-2">Name</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="name" name="name"
                            value="{{ $item->name }}" readonly="readonly">
                    </div>
                </div>                
                
                <div class="form-group">
                    <label for="code" class="col-md-2">Code</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="code" name="code"
                            value="{{ $item->code }}" readonly="readonly">
                    </div>
                </div>

                <div class="form-group">
                    <label for="code" class="col-md-2">Item Rated</label>
                    <div class="col-md-10"> 
                        <input type="text" class="form-control" id="code" name="code"
                            value="{{ $average }} out of 5!" readonly="readonly">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="code" class="col-md-2">Rate This Item</label>
                    <div class="col-md-10">
                    
                        @foreach (range(1,5) as $i)

                         @if ($i === $rating)
                            <input type ="radio" name="rating" value={{$i}} checked >        
                                @else
                                    <input type ="radio" name="rating" value={{$i}} >
                        @endif
                             {{$i}}
                            
                        @endforeach         

                    </div>
                </div>
                
                {{ csrf_field() }}
                <input type="hidden" name="id" value="{{ $item->id }}">

                <div class="col-md-10 col-md-offset-2">
                    </br>
                    <a href="{{ route('items.index') }}" class="link">Back to Items</a>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    
                    <input type="submit" value="Rate">

                    </br></br>
                </div>
            </form>
        </div>
    </div>
@endsection