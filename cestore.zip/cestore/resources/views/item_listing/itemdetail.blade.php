@extends('layouts.master')

@section('content')
    @include('partials.errors')
    @if(Session::has('info'))
            <div class="row">
                <div class="col-md-12">
                    <p class="alert alert-info">{{ Session::get('info') }}</p>
                </div>
            </div>
    @endif
    <div class="row">
        <div class="col-md-12">
            <h1>{{$item->name}}</h1>

            <div class="col-md-12"> <img src="{{$item->image_src}}" width="200px"></div>
            <div class="col-md-12">
                <h2>Product Details</h2>
                <h4>Manufactured by: {{$item->manufacturer->name}} </h4>
                <p>{{$item->description}}</p>
            </div>
            <div class="col-md-12">
                <form action="{{ route('cart') }}" method="post">
                    <input type="hidden" name="item_id" value="{{$item->id}}">
                    {{ csrf_field() }}
                    <input type="submit" class="btn btn-success pull-right" value="Add to Cart 2">
                </form>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <h4>Rated: {{$average}} out of 5!!! <br>
                {{$customersRated}} customer(s) rated this item
            </h4>

            <form action="{{ route('rates') }}" method="post">               
                
                <div class="form-group">
                    <label for="code" class="col-md-2">Rate This Item</label>
                    <div class="col-md-10">
                    
                        @foreach (range(1,5) as $i)

                         @if ($i === $rating)
                            <input type ="radio" name="rating" value={{$i}} checked >        
                                @else
                                    <input type ="radio" name="rating" value={{$i}} >
                        @endif
                             {{$i}}
                            
                        @endforeach         

                    </div>
                </div>
                
                {{ csrf_field() }}
                <input type="hidden" name="id" value="{{ $item->id }}">

                <div class="col-md-10 col-md-offset-2">
                    </br>
                    <a href="{{ route('display') }}" class="link">Back to items</a>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    
                    <input type="submit" value="Rate">

                    </br></br>
                </div>
            </form>
        </div>
    </div>
@endsection