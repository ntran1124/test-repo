@extends('layouts.master')

@section('content')
    @if(Session::has('info'))
        <div class="row">
            <div class="col-md-12">
                <p class="alert alert-info">{{ Session::get('info') }}</p>
            </div>
        </div>
    @endif

    <div class="row">
        <div class="col-md-12">
            <h3>CE Store Items: {{$items->total()}} total</h3>
                </p>Items {{$items->firstItem()}} - {{$items->lastItem()}}</p>
        </div>
    </div>
    {{$items->links()}}
    
    @foreach($items->chunk(4) as $itemChunk)    
        <div class="container"><div class="row"> 
        @foreach($itemChunk as $item)
            <div class="col-sm-6 col-md-4 col-lg-3">
                <div class="thumbnail"> 
                    <img src="{{$item->image_src}}" style="max-height:125px">
                    <div class="caption" style="height:200px">
                        <div class="clearfix">
                            <h4><a class="link" href="{{ route ('itemdetail', $item->id) }}">  {{$item->name}}</a></h4>
                                
                            @if(strlen($item->description) > 125)
                                <p>{{substr($item->description, 0, 125)}} ...</p>
                            @else
                                <p>{{$item->description}}</p>
                            @endif
                            
                            
                            <div class="price pull-left">$ {{$item->prices[0]->value}}</div>
                            <form action="{{ route('cart') }}" method="post">
                                <input type="hidden" name="item_id" value="{{$item->id}}">
                                {{ csrf_field() }}
                            <button type="submit" class="btn btn-success pull-right" role="button">Add to Cart</button>
                            </form>
                        </div>
                    </div>   
                </div>
            </div>
        @endforeach     
        </div></div>
    @endforeach
    {{$items->links()}}
    
  
       
@endsection