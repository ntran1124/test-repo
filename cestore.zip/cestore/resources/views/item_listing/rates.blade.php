@extends('layouts.master')

@section('content')
      
     

    <h1>You Have Succesfully Rated {{ $item->name }} </h1> 
    <p>Rating: {{$rating}} </p>  
    <p>Customer ID: {{$customer->id}}
    <p>Customer NAME: {{$customer->first_name}} </p>

@endsection