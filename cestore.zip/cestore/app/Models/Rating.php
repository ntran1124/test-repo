<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;



class RatingSave extends Model
{
    protected $fillable = ['id', 'item_id', 'item_name', 'rating', 'customer_id'];

    public function Item() {
        return $this->belongsTo('App\Models\Item', 'item_id');

    }
    
    /*public function Customer() {
        return $this->belongsTo('App\Models\Customer', 'customer_id');
    }*/

}