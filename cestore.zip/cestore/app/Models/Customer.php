<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    protected $fillable = ['first_name', 'last_name', 'company_name', 'address', 'user_id'];


    public function Items() {
        return $this->belongsToMany('App\Models\Item', 'ratings')
        ->withPivot('rating');  

    }


}