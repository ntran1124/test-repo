<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Price extends Model
{
    protected $fillable = ['category_id', 'manufacturer', 'code', 'name', 'description'];

    public function Item() {
        return $this->belongsTo('App\Models\Item', 'item_id');
    }
}