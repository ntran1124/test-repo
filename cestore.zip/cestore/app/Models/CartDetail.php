<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class CartDetail extends Model
{
    // protected $fillable = ['category_id', 'manufacturer', 'code', 'name', 'description'];

    public function Cart() {
        return $this->belongsTo('App\Models\Cart', 'cart_id');
    }
    
    public function Item() {
        return $this->belongsTo('App\Models\Item', 'item_id');
    }
}