<?php

// The controller defines all the LOGIC for a given view 
// getRate just calls the rates.blade.php 

namespace App\Services;

use App\Models\Cart;
use App\Models\Item;
use App\Models\CartDetail;
use App\Http\Controllers\ItemsController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Blade;

class ShoppingCartService {

    public static function addItemToCart($cart_id, $item_id) {
        $cart = Cart::find($cart_id);
        $cart_detail = $cart->CartDetails->where("item_id", $item_id)->first();
        if (is_null($cart_detail)) {
            ShoppingCartService::addNewItemToCart($cart_id, $item_id); 
        }
        else {
            $new_quantity = $cart_detail->quantity++;
            ShoppingCartService::updateQuantityOfCardDetail($cart_detail->id, $new_quantity);
        }
    }

    public static function addNewItemToCart($cart_id, $item_id) {
        $new_sequence_number = 0;
        
        foreach (CartDetail::where("cart_id", $cart_id) as $cart_detail) {
            $new_sequence_number = max($new_sequence_number, $cart_detail->sequence_number);
        }
        $new_sequence_number++;
        //
        $cart_detail = new CartDetail();
        $cart_detail->cart_id = $cart_id;
        $cart_detail->sequence_number = $new_sequence_number;
        $cart_detail->item_id = $item_id;
        $cart_detail->price = ItemsController::getCurrentItemPrice($item_id);
        $cart_detail->quantity = 1;
        $cart_detail->save();
        //
        ShoppingCartService::computeCartInfoOfCart($cart_id);


    }

    public static function getCartBySessionId($session_id) {
        $carts = Cart::where('session_id', $session_id);
        $cart = new Cart();
        if ($carts->count() > 0) {
            $cart = $carts->first();
        }
        else {
            $cart->session_id = $session_id;
            $cart->sub_total = 0;
            $cart->discount_amount = 0;
            $cart->total = 0;

            $cart->save();
        }

        return $cart;
    }

    public static function updateQuantityOfCardDetail($cart_detail_id, $quantity) {
        $cart_detail = CartDetail::find($cart_detail_id);
        $card_id = $cart_detail->cart_id;        

        if ($quantity == 0) {
            $cart_detail->delete();
        } 
        else {
            $cart_detail->quantity = $quantity;
            $cart_detail->save();
        }
        
        ShoppingCartService::computeCartInfoOfCart($card_id);
    }

    public static function computeCartInfoOfCart($cart_id) {
        $cart = Cart::find($cart_id);
        $sub_total = 0;
        foreach ($cart->CartDetails as $cart_detail) {
            $sub_total += $cart_detail->price * $cart_detail->quantity;
        }
        $cart->sub_total = $sub_total;
        $cart->total = $cart->sub_total - $cart->discount_amount;
        $cart->save();
    }
}
