<?php

// The controller defines all the LOGIC for a given view 
// getRate just calls the rates.blade.php 

namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\Item;
use App\Models\CartDetail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Blade;
use App\Services\ShoppingCartService;

class CartController extends Controller {

    public function index(Request $request)
    {
        $session_id = $request->session()->getId();
        // Get current cart via a service
        $cart = ShoppingCartService::getCartBySessionId($session_id);
        $cart_details = $cart->CartDetails;

        return view('cart.index', ['cart' => $cart, 'cart_details' => $cart_details]);
         
    }        

    public function postItem(Request $request)
    {
        $session_id = $request->session()->getId();
        // Get current cart via a service
        $cart = ShoppingCartService::getCartBySessionId($session_id);
        $cart_id = $cart->id;
        
        $item_id = $request->input("item_id");
        // Add item to cart via a service
        $cart = ShoppingCartService::addItemToCart($cart->id, $item_id);
        
        // Retrieve Cart again for passing to view
        $cart = Cart::find($cart_id);
        $cart_details = $cart->CartDetails;

        return view('cart.index', ['cart' => $cart, 'cart_details' => $cart_details]);
    }

    public function addItemToCart($cart_id, $item_id) {
        $cart = Cart::find($cart_id);
        $cart_detail = $cart->CartDetails->where("item_id", $item_id)->first();
        if (is_null($cart_detail)) {
            ShoppingCartService::addNewItemToCart($cart_id, $item_id); 
        }
        else {
            $new_quantity = $cart_detail->quantity++;            
            ShoppingCartService::updateQuantityOfCardDetail($cart_detail->id, $new_quantity);
        }
    }

    public function addNewItemToCart($cart_id, $item_id) {
        $new_sequence_number = 0;
        
        foreach (CartDetail::where("cart_id", $cart_id) as $cart_detail) {
            $new_sequence_number = max($new_sequence_number, $cart_detail->sequence_number);
        }
        $new_sequence_number++;
        //
        $cart_detail = new CartDetail();
        $cart_detail->cart_id = $cart_id;
        $cart_detail->sequence_number = $new_sequence_number;
        $cart_detail->item_id = $item_id;
        $cart_detail->price = ItemsController::getCurrentItemPrice($item_id);
        $cart_detail->quantity = 1;
        $cart_detail->save();
        //
        ShoppingCartService::computeCartInfoOfCart($cart_id);


    }

    public function getCartBySessionId($session_id) {
        $carts = Cart::where('session_id', $session_id);
        $cart = new Cart();
        if ($carts->count() > 0) {
            $cart = $carts->first();
        }
        else {
            $cart->session_id = $session_id;
            $cart->sub_total = 0;
            $cart->discount_amount = 0;
            $cart->total = 0;

            $cart->save();
        }

        return $cart;
    }
}
