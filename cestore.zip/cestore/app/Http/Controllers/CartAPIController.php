<?php

// The controller defines all the LOGIC for a given view 
// getRate just calls the rates.blade.php 

namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\Item;
use App\Models\CartDetail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\Input;
use App\Services\ShoppingCartService;

class CartAPIController extends Controller {
    
    public function __construct()
    {
        // $this->middleware('name');
    }

    public function getCart()
    {
        return "It works!";
    }

    public function postCart(Request $request)
    {
        // Get posting data
        $data = Input::all();
        $cart_detail_id = $data['cart_detail_id'];
        $quantity = $data['quantity'];       

        // Get cart info
        $cart_detail = CartDetail::find($cart_detail_id);
        $cart_id = $cart_detail->cart_id;
        
        // Update quantity via a service
        ShoppingCartService::updateQuantityOfCardDetail($cart_detail_id, $quantity);

        // Get cart object from model after quantity being updated
        $cart = Cart::find($cart_id);
        $cart->load('CartDetails');

        return $cart->toJson();
    }

    // public static function updateQuantityOfCardDetail($id, $quantity) {
    //     $cart_detail = CartDetail::find($id);
    //     $card_id = $cart_detail->cart_id;        

    //     if ($quantity == 0) {
    //         $cart_detail->delete();
    //     } 
    //     else {
    //         $cart_detail->quantity = $quantity;
    //         $cart_detail->save();
    //     }
        
    //     CartAPIController::computeCartInfoOfCart($card_id);
    // }

    // public static function computeCartInfoOfCart($id) {
    //     $cart = Cart::find($id);
    //     $sub_total = 0;
    //     foreach ($cart->CartDetails as $cart_detail) {
    //         $sub_total += $cart_detail->price * $cart_detail->quantity;
    //     }
    //     $cart->sub_total = $sub_total;
    //     $cart->total = $cart->sub_total - $cart->discount_amount;
    //     $cart->save();
    // }
}
