<?php

namespace App\Http\Controllers;

use App\Models\Manufacturer;
use Illuminate\Http\Request;

class ManufacturersController extends Controller
{
    public function getIndex()
    {
        $manufacturers = Manufacturer::orderBy('name', 'asc')->get();
        return view('manufacturers.index', ['manufacturers' => $manufacturers]);
    }

     public function getDetail($id)
    {
        $manufacturer = Manufacturer::find($id);
        return view('manufacturers.detail', ['manufacturer' => $manufacturer]);
    }

    public function getCreate()
    {
        $manufacturers = Manufacturer::all();
        return view('manufacturers.create', ['manufacturers' => $manufacturers]);
    }

    public function postCreate(Request $request)
    {
        $this->validate($request, [
            'name' => 'required|min:2',
            'phone' => 'required|min:1',
            'homepage' => 'required|min:1'
        ]);
        $manufacturer = new Manufacturer();
        $manufacturer->name = $request->input('name');
        $manufacturer->phone = $request->input('phone');
        $manufacturer->homepage = $request->input('homepage');

        $manufacturer->save();

        return redirect()
                    ->route('manufacturers.index')
                    ->with('info', $manufacturer->name.' manufacturer has been created with id='.$manufacturer->id);
    }

    public function getUpdate($id)
    {
        $manufacturer = Manufacturer::find($id);
        return view('manufacturers.update', ['manufacturer' => $manufacturer]);
    }

    public function postUpdate(Request $request)
    {
        $manufacturer = Manufacturer::find($request->input('id'));
        $manufacturer->name = $request->input('name');
        $manufacturer->phone = $request->input('phone');
        $manufacturer->homepage = $request->input('homepage');
        $manufacturer->save();
        
        return redirect()
                ->route('manufacturers.index')
                ->with('info', $manufacturer->name.' manufacturer has been updated.');
    }

    public function getDelete($id)
    {
        $manufacturer = Manufacturer::find($id);
        return view('manufacturers.delete', ['manufacturer' => $manufacturer]);
    }

    public function postDelete(Request $request)
    {
        $manufacturer = Manufacturer::find($request->input('id'));
        $manufacturer->delete();
        
        return redirect()
                ->route('manufacturers.index')
                ->with('info', $manufacturer->name.' manufacturer has been deleted.');
    }
}
