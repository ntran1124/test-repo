<?php

namespace App\Http\Controllers;

use App\Models\Manufacturer;
use App\Models\Supplier;
use Illuminate\Http\Request;

class SuppliersController extends Controller
{
    public function getIndex()
    {
        $suppliers = supplier::orderBy('name', 'asc')->get();
        return view('suppliers.index', ['suppliers' => $suppliers]);
    }

     public function getDetail($id)
    {
        $supplier = Supplier::find($id);
        return view('suppliers.detail', ['supplier' => $supplier]);
    }

    public function getCreate()
    {
        $suppliers = Supplier::all();
        return view('suppliers.create', ['suppliers' => $suppliers]);
    }

    public function postCreate(Request $request)
    {
        $this->validate($request, [
            'name' => 'required|min:2',
            'is_direct_sales' => 'required|min:1',
            'contact_name' => 'required|min:1',
            'phone' => 'required|min:1',
            'address' => 'required|min:1'
        ]);

        $supplier = new Supplier();
        $supplier->name = $request->input('name');
        $supplier->is_direct_sales = $request->input('is_direct_sales');
        $supplier->contact_name = $request->input('contact_name');
        $supplier->contact_title = $request->input('contact_title');
        $supplier->phone = $request->input('phone');
        $supplier->fax = $request->input('fax');
        $supplier->email = $request->input('email');
        $supplier->homepage = $request->input('homepage');
        $supplier->address = $request->input('address');

        $supplier->save();

        return redirect()
                    ->route('suppliers.index')
                    ->with('info', $supplier->name.' supplier has been created with id='.$supplier->id);
    }

    public function getUpdate($id)
    {
        $supplier = Supplier::find($id);
        return view('suppliers.update', ['supplier' => $supplier]);
    }

    public function postUpdate(Request $request)
    {
        $supplier = Supplier::find($request->input('id'));
        $supplier->name = $request->input('name');
        $supplier->is_direct_sales = $request->input('is_direct_sales');
        $supplier->contact_name = $request->input('contact_name');
        $supplier->contact_title = $request->input('contact_title');
        $supplier->phone = $request->input('phone');
        $supplier->fax = $request->input('fax');
        $supplier->email = $request->input('email');
        $supplier->homepage = $request->input('homepage');
        $supplier->address = $request->input('address');
        $supplier->save();
        
        return redirect()
                ->route('suppliers.index')
                ->with('info', $supplier->name.' supplier has been updated.');
    }

    public function getDelete($id)
    {
        $supplier = Supplier::find($id);
        return view('suppliers.delete', ['supplier' => $supplier]);
    }

    public function postDelete(Request $request)
    {
        $supplier = Supplier::find($request->input('id'));
        $supplier->delete();
        
        return redirect()
                ->route('suppliers.index')
                ->with('info', $supplier->name.' supplier has been deleted.');
    }
}
