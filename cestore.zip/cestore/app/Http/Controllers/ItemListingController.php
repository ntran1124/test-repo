<?php

// The controller defines all the LOGIC for a given view 
// getRate just calls the rates.blade.php 

namespace App\Http\Controllers;

use App\Models\Item;
use App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Blade;

class ItemListingController extends Controller {
    
    public function getItemListing() {

    }

    public function getDisplay() {
       $items = Item::orderBy('id', 'asc')->paginate(8);
       // $items = Item::orderBy('name', 'asc')->get();
        // ->take(14) to get certain number

        $null_image_link = "images/image-not-available.png";

         foreach($items as $item) {
            if($item->image_src === null)
                $item->image_src = $null_image_link;
            
            itemListingController::setPrice($item->prices);
         }

        return view('item_listing.display', ['items' => $items]);
    }
    
    public function setPrice($prices){
        $temp_prices = $prices->sortByDesc('set_date');
        $current_date = date("Y-m-d H:i:s");
        $current_price = 0;
      
        foreach($temp_prices as $price) {
           if($price->set_date <= $current_date) {
                $current_price = $price->value;
                break;
            }
    }
        $prices[0]->value = $current_price;
    }

public function postAddToCart()
    {
        
        //  $items = Item::orderBy('id', 'asc')->paginate(8);
        // $null_image_link = "/cestore/public/images/imageNotAvailable.png";

        //  foreach($items as $item) {
        //     if($item->image_src === null)
        //         $item->image_src = $null_image_link;
            
        //     itemListingController::setPrice($item->prices);
        //     }
        


        return view('cart', ['cart' => $cart]);
         

        // return redirect()
        //         ->route('display')
        //         ->with('info', 'has been added to cart.');
    }




    public function getDetail($id) {
        $item = Item::find($id);
        $rating = 3;

        $current_average_rating = 3.5;
        $rating_sum = 0;

         if ($item->Customers->isNotEmpty()) {

            foreach ( $item->Customers as $customer_rating) {

                    $rating_sum = $rating_sum + $customer_rating->pivot->rating;
            }

            $current_average_rating = $rating_sum / $item->Customers->count();

            return view('item_listing.itemdetail', ['item' => $item, 'rating'=>$rating, 'average' => $current_average_rating, 
                        'customersRated' => $item->Customers->count()
            ]);

         }  else {

                return view('item_listing.itemdetail', ['item' => $item, 'rating'=>$rating, 'average' => 0, 'customersRated' => 0]);
         }

    }


    public function postRate(Request $request) {
        
        $user = Auth::user();
        $customer = Customer::where('user_id', '=', $user->id)->first();
        $customer_id = $customer->id;
        
        $item = Item::find($request->input('id'));
        $rating = $request->input('rating');

        if ($item->Customers->contains($customer_id)) {

           return redirect()
                    ->route('itemdetail', ['id'=>$item->id])
                    ->with('info', $customer->first_name . ', you have already rated ' . $item->name);

        } else {

            $item->Customers()->attach($customer_id, ['rating'=> $rating]);
            return view('item_listing.rates', ['item' => $item])->withCustomer($customer)->withRating($rating);

            }

      
         
    }

}
