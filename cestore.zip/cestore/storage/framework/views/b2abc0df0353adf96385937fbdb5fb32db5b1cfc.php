<nav class="navbar">
  <div class="container-fluid">
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav nav-pills nav-stacked">
        <li><a href="<?php echo e(route('display')); ?>">Display Page</a></li>
        <li><a href="<?php echo e(route('cart')); ?>"><span class="glyphicon glyphicon-shopping-cart"></span> Shopping Cart</a></li>
      </ul>     
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>