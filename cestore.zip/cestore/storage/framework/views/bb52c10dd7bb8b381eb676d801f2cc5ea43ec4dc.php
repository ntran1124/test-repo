<?php $__env->startSection('content'); ?>
    <?php if(Session::has('info')): ?>
        <div class="row">
            <div class="col-md-12">
                <p class="alert alert-info"><?php echo e(Session::get('info')); ?></p>
            </div>
        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <h3><?php echo e($item->name); ?> - Prices</h3>
            <hr>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <table>
                <tr>
                    <td>
                        <form action="<?php echo e(route('items.priceitem')); ?>" method="post">
                            <div class="form-group">
                                <label for="value" class="col-md-4">Price:</label>
                                <div class="col-md-8">
                                    <input type="text" class="form-control" id="value" name="value">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="set_date" class="col-md-4">Effective date:</label>
                                <div class="col-md-8">
                                    <input type="text" class="form-control" id="set_date" name="set_date">
                                </div>
                            </div>              

                            <?php echo e(csrf_field()); ?>

                            <div class="col-md-8 col-md-offset-4">
                                <br>
                                <input type="hidden" id="item_id" name="item_id" value="<?php echo e($item->id); ?>">
                                <button type="submit" class="btn btn-primary">Set price</button> 
                                <a href="<?php echo e(route("items.index")); ?>" class="btn btn-primary">Back</a>
                            </div>
                        </form>    
                    </td>
                </tr>
            </table>
        </div>
        <div class="col-md-6">
            <table class="table table-responsive">
                <tr>
                    <td><b>Price</b></td>
                    <td><b>Effective date</b></td>
                </tr>
                <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        $<?php echo e(number_format($price->value, 2, '.', ',')); ?>

                    </td>
                    <td>
                        <?php echo e($price->set_date); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>    
    </div>
    <div class="row">
        <div class="col-md-12">
            
            <hr>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>