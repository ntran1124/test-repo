

<?php $__env->startSection('content'); ?>
    <?php if(Session::has('info')): ?>
        <div class="row">
            <div class="col-md-12">
                <p class="alert alert-info"><?php echo e(Session::get('info')); ?></p>
            </div>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-12">
            <h3>CE Store Items: <?php echo e($items->total()); ?> total</h3>
                </p>Items <?php echo e($items->firstItem()); ?> - <?php echo e($items->lastItem()); ?></p>
        </div>
    </div>
    <?php echo e($items->links()); ?>

    
    <?php $__currentLoopData = $items->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemChunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
        <div class="container"><div class="row"> 
        <?php $__currentLoopData = $itemChunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-6 col-md-4 col-lg-3">
                <div class="thumbnail"> 
                    <img src="<?php echo e($item->image_src); ?>" style="max-height:125px">
                    <div class="caption" style="height:200px">
                        <div class="clearfix">
                            <h4><a class="link" href="<?php echo e(route ('itemdetail', $item->id)); ?>">  <?php echo e($item->name); ?></a></h4>
                                
                            <?php if(strlen($item->description) > 125): ?>
                                <p><?php echo e(substr($item->description, 0, 125)); ?> ...</p>
                            <?php else: ?>
                                <p><?php echo e($item->description); ?></p>
                            <?php endif; ?>
                            
                            
                            <div class="price pull-left">$ <?php echo e($item->prices[0]->value); ?></div>
                            <form action="<?php echo e(route('cart')); ?>" method="post">
                                <input type="hidden" name="item_id" value="<?php echo e($item->id); ?>">
                                <?php echo e(csrf_field()); ?>

                            <button type="submit" class="btn btn-success pull-right" role="button">Add to Cart</button>
                            </form>
                        </div>
                    </div>   
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
        </div></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($items->links()); ?>

    
  
       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>