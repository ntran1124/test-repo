<?php $__env->startSection('content'); ?>
    <?php if(Session::has('info')): ?>
        <div class="row">
            <div class="col-md-12">
                <p class="alert alert-info"><?php echo e(Session::get('info')); ?></p>
            </div>
        </div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-md-12">
            <h3>Suppliers</h3>
        </div>
    </div>

    <div style="max-height:350px; overflow:scroll;">
            <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <div class="col-sm-2">
                        <?php echo e($supplier->name); ?>

                    </div>
                    <div class="col-sm-2">
                        <?php echo e($supplier->contact_name); ?>

                    </div>
                    <div class="col-sm-2">
                        <?php echo e($supplier->phone); ?>

                    </div>
                    <div class="col-sm-3">
                        <?php echo e($supplier->homepage); ?>

                    </div>
                    <div class="col-sm-1">
                        <a class="link" href="<?php echo e(route('suppliers.detail', ['id' => $supplier->id])); ?>">Detail</a>    
                    </div>
                    <div class="col-sm-1">
                        <a class="link" href="<?php echo e(route('suppliers.update', ['id' => $supplier->id])); ?>">Update</a>
                    </div>
                    <div class="col-sm-1">
                        <a class="link" href="<?php echo e(route('suppliers.delete', ['id' => $supplier->id])); ?>">Delete</a>
                    </div>
                </div>
                <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="row"> <br> </div>
            <div class="col-md-12">
                <a class="link" href="<?php echo e(route('suppliers.create')); ?>">Create a new supplier</a>
                <hr>
            </div>
    </div>


            <div class = row> <br> </div>
        </div>
    





    




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>