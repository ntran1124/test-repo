<?php $__env->startSection('content'); ?>
      
     

    <h1>You Have Succesfully Rated <?php echo e($item->name); ?> </h1> 
    <p>Rating: <?php echo e($rating); ?> </p>  
    <p>Customer ID: <?php echo e($customer->id); ?>

    <p>Customer NAME: <?php echo e($customer->first_name); ?> </p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>