<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-md-12">
            <form action="<?php echo e(route('departments.updateDepartment')); ?>" method="post">
                <div class="form-group">
                    <label for="name" class="col-md-2">Name</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="name" name="name" 
                            value="<?php echo e($department->name); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label for="description" class="col-md-2">Description</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="description" name="description"
                            value="<?php echo e($department->description); ?>">
                    </div>
                </div>
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="id" value="<?php echo e($department->id); ?>">
                <div class="col-md-10 col-md-offset-2">
                    <button type="submit" class="btn btn-primary">Update</button> 
                    <a href="<?php echo e(route("departments.index")); ?>" class="btn btn-primary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>