<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-md-12">
            <form action="<?php echo e(route('items.updateItem')); ?>" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="manufacturer_id" class="col-md-2">Manufacturer</label>
                    <div class="col-md-10">
                        <select class="form-control" id="manufacturer_id" name="manufacturer_id">
                            <?php $__currentLoopData = $manufacturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manufacturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($manufacturer->id == $item->manufacturer_id): ?>
                                    <option value="<?php echo e($manufacturer->id); ?>" selected>
                                        <?php echo e($manufacturer->name); ?>

                                    </option>
                                <?php else: ?>
                                    <option value="<?php echo e($manufacturer->id); ?>">
                                        <?php echo e($manufacturer->name); ?>

                                    </option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>                    
                <div class="form-group">
                    <label for="category_id" class="col-md-2">Category</label>
                    <div class="col-md-10">
                        <select class="form-control" id="category_id" name="category_id">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($category->id == $item->category_id): ?>
                                    <option value="<?php echo e($category->id); ?>" selected>
                                        <?php echo e($category->name); ?>

                                    </option>
                                <?php else: ?>
                                    <option value="<?php echo e($category->id); ?>">
                                        <?php echo e($category->name); ?>

                                    </option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>                    
                <div class="form-group">
                    <label for="name" class="col-md-2">Name</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="name" name="name"
                            value="<?php echo e($item->name); ?>">
                    </div>
                </div>                
                <div class="form-group">
                    <label for="code" class="col-md-2">Code</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="code" name="code"
                            value="<?php echo e($item->code); ?>">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="description" class="col-md-2">Description</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="description" name="description"
                            value="<?php echo e($item->description); ?>">
                    </div>
                </div>

                <div class="form-group">
                    <label for="image_src" class="col-md-2">Image Link</label>
                    <div class="col-md-10">
                        <input type="file" class="form-control" id="image_src" name="image_src">
                    </div>
                </div>
                
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                <div class="col-md-10 col-md-offset-2">
                    <br>
                    <button type="submit" class="btn btn-primary">Update</button> 
                    <a href="<?php echo e(route("items.index")); ?>" class="btn btn-primary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>