<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <form action="<?php echo e(route('categories.detail', ['id' => $category->id])); ?>" method="get">
                <div class="form-group">
                    <label for="department_name" class="col-md-2">Department</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="department_name" name="department_name"
                            value="<?php echo e($category->department->name); ?>" readonly="readonly">
                    </div>
                </div>                    
                <div class="form-group">
                    <label for="name" class="col-md-2">Name</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="name" name="name"
                            value="<?php echo e($category->name); ?>" readonly="readonly">
                    </div>
                </div>                
                <div class="form-group">
                    <label for="code" class="col-md-2">Code</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="code" name="code"
                            value="<?php echo e($category->code); ?>" readonly="readonly">
                    </div>
                </div>
                <div class="form-group">
                    <label for="description" class="col-md-2">Description</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="description" name="description"
                            value="<?php echo e($category->description); ?>" readonly="readonly">
                    </div>
                </div>                
                <div class="form-group">
                    <label for="created_at" class="col-md-2">Created At</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="created_at" name="created_at"
                            value="<?php echo e($category->created_at); ?>" readonly="readonly">
                    </div>
                </div>
                <div class="form-group">
                    <label for="updated_at" class="col-md-2">Updated At</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="updated_at" name="updated_at"
                            value="<?php echo e($category->updated_at); ?>" readonly="readonly">
                    </div>
                </div>
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="id" value="<?php echo e($category->id); ?>">
                <div class="col-md-10 col-md-offset-2">
                    </br>
                    <a href="<?php echo e(route('categories.index')); ?>" class="link">Back to Categories</a>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <a href="<?php echo e(route('categories.update', ['id' => $category->id])); ?>" class="link">Update this category</a>
                    </br></br>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>