<?php $__env->startSection('content'); ?>
    <?php if(Session::has('info')): ?>
        <div class="row">
            <div class="col-md-12">
                <p class="alert alert-info"><?php echo e(Session::get('info')); ?></p>
            </div>
        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <h3>Departments</h3>
        </div>
    </div>
    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
        <div class="col-md-1">
            <?php echo e($department->id); ?>

        </div>
        <div class="col-md-3">
            <?php echo e($department->name); ?>

        </div>
        <div class="col-md-6">
            <?php echo e($department->description); ?>

        </div>
        <div class="col-md-1">
            <a class="link" href="<?php echo e(route('departments.update', ['id' => $department->id])); ?>">Update</a>
        </div>
        <div class="col-md-1">
            <a class="link" href="<?php echo e(route('departments.delete', ['id' => $department->id])); ?>">Delete</a>
        </div>
    </div>
    <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
        <div class="col-md-12">
            <a class="link" href="<?php echo e(route('departments.create')); ?>">Create a new department</a>
            <hr>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>