<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" 
            href="http://cestore.dev:8009/css/themes/united/bootstrap.min.css">
        <title>CE Store</title>        
    </head>
    <body clase>
        <div class="container"><?php echo $__env->make('partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
        <div class="row container">
              <div class="col-md-2"><?php echo $__env->make('partials.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
                <div class="col-md-10"><?php echo $__env->yieldContent('content'); ?></div>
        </div>
        <div class="container"><?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
    </body>
</html>
