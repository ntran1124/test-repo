<?php $__env->startSection('content'); ?>
<h1>Some content</h1>
<P><?php echo e(2 == 3 ? "HELLO" : "Does not equal"); ?></P>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>