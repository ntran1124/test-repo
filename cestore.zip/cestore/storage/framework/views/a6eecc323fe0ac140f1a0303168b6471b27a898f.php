<?php $__env->startSection('content'); ?>
    <?php if(Session::has('info')): ?>
        <div class="row">
            <div class="col-md-12">
                <p class="alert alert-info"><?php echo e(Session::get('info')); ?></p>
            </div>
        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <h3>Manufacturers</h3>
        </div>
    </div>
    
    <div style="max-height:350px; overflow:scroll;">
        <?php $__currentLoopData = $manufacturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manufacturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
                <div class="col-sm-1">
                    <?php echo e($manufacturer->id); ?>

                </div>
                <div class="col-sm-2">
                    <?php echo e($manufacturer->name); ?>

                </div>
                <div class="col-sm-2">
                    <?php echo e($manufacturer->phone); ?>

                </div>
                <div class="col-sm-4">
                    <?php echo e($manufacturer->homepage); ?>

                </div>
                <div class="col-sm-1">
                    <a class="link" href="<?php echo e(route('manufacturers.detail', ['id' => $manufacturer->id])); ?>">Detail</a>
                </div>
                <div class="col-sm-1">
                    <a class="link" href="<?php echo e(route('manufacturers.update', ['id' => $manufacturer->id])); ?>">Update</a>
                </div>
                <div class="col-sm-1">
                    <a class="link" href="<?php echo e(route('manufacturers.delete', ['id' => $manufacturer->id])); ?>">Delete</a>
                </div>
            </div>
            <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
        <div class = row> <br> </div>
        <div class = row>
        <div class="col-md-12">
            <a class="link" href="<?php echo e(route('manufacturers.create')); ?>">Create a new Manufacturer</a>
            <hr>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>