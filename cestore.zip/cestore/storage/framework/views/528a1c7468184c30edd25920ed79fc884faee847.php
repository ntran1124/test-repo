<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-md-12">
            <form action="<?php echo e(route('categories.create')); ?>" method="post">
                <div class="form-group">
                    <label for="department_id" class="col-md-2">Department</label>
                    <div class="col-md-10">
                        <select class="form-control" id="department_id" name="department_id">
                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label for="name" class="col-md-2">Name</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="name" name="name">
                    </div>
                </div>                
                
                <div class="form-group">
                    <label for="code" class="col-md-2">Code</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="code" name="code">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="description" class="col-md-2">Description</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="description" name="description">
                    </div>
                </div>
                
                <?php echo e(csrf_field()); ?>

                <div class="col-md-10 col-md-offset-2">
                    <button type="submit" class="btn btn-primary">Create</button> 
                    <a href="<?php echo e(route("categories.index")); ?>" class="btn btn-primary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>