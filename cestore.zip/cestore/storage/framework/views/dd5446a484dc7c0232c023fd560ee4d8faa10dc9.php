<?php $__env->startSection('content'); ?>
    <?php if(Session::has('info')): ?>
        <div class="row">
            <div class="col-md-12">
                <p class="alert alert-info"><?php echo e(Session::get('info')); ?></p>
            </div>
        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <h3>Categories</h3>
        </div>
    </div>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
        <div class="col-md-1">
            <?php echo e($category->id); ?>

        </div>
        <div class="col-md-2">
            <?php echo e($category->name); ?>

        </div>
        <div class="col-md-1">
            <?php echo e($category->code); ?>

        </div>
        <div class="col-md-3">
            <?php echo e($category->description); ?>

        </div>
        <div class="col-md-2">
            <?php echo e($category->department->name); ?>

        </div>
        <div class="col-md-3">
            <a class="link" href="<?php echo e(route('categories.detail', ['id' => $category->id])); ?>">Detail</a>
            &nbsp;&nbsp;
            <a class="link" href="<?php echo e(route('categories.update', ['id' => $category->id])); ?>">Update</a>
            &nbsp;&nbsp;
            <a class="link" href="<?php echo e(route('categories.delete', ['id' => $category->id])); ?>">Delete</a>
        </div>
    </div>
    <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
        <div class="col-md-12">
            <a class="link" href="<?php echo e(route('categories.create')); ?>">Create a new category</a>
            <hr>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>