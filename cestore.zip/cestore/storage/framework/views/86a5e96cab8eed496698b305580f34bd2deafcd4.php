<?php $__env->startSection('content'); ?>
    
    <div class="row">
        <div class="col-md-12">
             <form>
                <div class="form-group">
                    <label for="name" class="col-md-2">Name</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="name" name="name" 
                            value="<?php echo e($department->name); ?>" readonly>
                    </div>
                </div>
                <div class="form-group">
                    <label for="description" class="col-md-2">Description</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="description" name="description"
                            value="<?php echo e($department->description); ?>" readonly>
                    </div>
                </div>
                <div class="form-group">
                    <label for="created_at" class="col-md-2">Created On</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="created_at" name="created_at"
                            value="<?php echo e($department->created_at); ?>" readonly>
                    </div>
                </div>
                <div class="form-group">
                    <label for="updated_at" class="col-md-2">Updated On</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="updated_at" name="updated_at"
                            value="<?php echo e($department->updated_at); ?>" readonly>
                    </div>
                </div>

                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="id" value="<?php echo e($department->id); ?>">
                <div class="col-md-10 col-md-offset-2">
                    <a href="<?php echo e(route("departments.index")); ?>" class="btn btn-primary">Go Back</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>