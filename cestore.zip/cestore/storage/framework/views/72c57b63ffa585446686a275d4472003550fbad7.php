<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-md-12">
            <form action="<?php echo e(route('manufacturers.updateManufacturer')); ?>" method="post">
                <div class="form-group">
                    <label for="name" class="col-md-2">Name</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="name" name="name" 
                            value="<?php echo e($manufacturer->name); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label for="phone" class="col-md-2">Phone Number</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="phone" name="phone"
                            value="<?php echo e($manufacturer->phone); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label for="homepage" class="col-md-2">Homepage</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="homepage" name="homepage"
                            value="<?php echo e($manufacturer->homepage); ?>">
                    </div>
                </div>
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="id" value="<?php echo e($manufacturer->id); ?>">
                <div class="col-md-10 col-md-offset-2">
                    <button type="submit" class="btn btn-primary">Update</button> 
                    <a href="<?php echo e(route("manufacturers.index")); ?>" class="btn btn-primary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>