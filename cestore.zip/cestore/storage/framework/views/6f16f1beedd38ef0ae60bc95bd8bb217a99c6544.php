<?php $__env->startSection('content'); ?>
    <?php if(Session::has('info')): ?>
        <div class="row">
            <div class="col-md-12">
                <p class="alert alert-info"><?php echo e(Session::get('info')); ?></p>
            </div>
        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <h3>Items</h3>
        </div>
    </div>
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
        <div class="col-md-1">
            <?php echo e($item->id); ?>

        </div>
        <div class="col-md-2">
            <?php echo e($item->name); ?>

        </div>
        <div class="col-md-1">
            <?php echo e($item->code); ?>

        </div>
        <div class="col-md-3">
            <?php echo e($item->description); ?>

        </div>
        <div class="col-md-2">
            <?php echo e($item->category->name); ?>

        </div>
        <div class="col-md-3">
            <a class="link" href="<?php echo e(route('items.detail', ['id' => $item->id])); ?>">Detail</a>
            &nbsp;&nbsp;
            <a class="link" href="<?php echo e(route('items.update', ['id' => $item->id])); ?>">Update</a>
            &nbsp;&nbsp;
            <a class="link" href="<?php echo e(route('items.delete', ['id' => $item->id])); ?>">Delete</a>
        </div>
    </div>
    <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
        <div class="col-md-12">
            <a class="link" href="<?php echo e(route('items.create')); ?>">Create a new item</a>
            <hr>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>