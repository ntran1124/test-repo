<?php $__env->startSection('content'); ?>
    <?php if(Session::has('info')): ?>
        <div class="row">
            <div class="col-md-12">
                <p class="alert alert-info"><?php echo e(Session::get('info')); ?></p>
            </div>
        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <h3>Shopping cart</h3>
        </div>
    </div>
    <?php if($cart_details->count() == 0): ?>
        <div class="row">
            <div class="col-md-12">
                Your cart is empty. 
                <br>
                <br>
                Please <a href="display">continue shopping</a>.
            </div>
        </div>
    <?php else: ?>
        <div id="columnTitle" id="columnTitle" class="row">
            <div class="col-md-1">
                #
            </div>
            <div class="col-md-5">
                Item Name
            </div>
            <div class="col-md-2">
                Price
            </div>
            <div class="col-md-2">
                Quantity
            </div>
            <div class="col-md-2 text-right">
                Sub total
            </div>        
            <div class="col-md-12">
                <hr>
            </div>
        </div>
        <?php $__currentLoopData = $cart_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div id="item_<?php echo e($cart_detail->item_id); ?>" name="item_<?php echo e($cart_detail->item_id); ?>" class="row">
            <div class="col-md-1">
                <?php echo e($cart_detail->sequence_number); ?>

            </div>
            <div class="col-md-5">
                <?php echo e($cart_detail->Item->name); ?>

            </div>
            <div class="col-md-2">
                <?php echo e(number_format($cart_detail->price, 2)); ?>

            </div>
            <div class="col-md-2">
                <select id="quantity_<?php echo e($cart_detail->item_id); ?>" name="quantity_<?php echo e($cart_detail->item_id); ?>" class="quantity_<?php echo e($cart_detail->item_id); ?>">
                    <option value="0">0 (remove)</option>
                    <?php $__currentLoopData = range(1,10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($cart_detail->quantity == $i): ?>
                            <option value="<?php echo e($i); ?>" selected><?php echo e($i); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div id="itemSubTotal_<?php echo e($cart_detail->item_id); ?>" name="itemSubTotal_<?php echo e($cart_detail->item_id); ?>" class="col-md-2 text-right">
                <?php echo e(number_format($cart_detail->price * $cart_detail->quantity, 2)); ?>

            </div>
            <div class="col-md-12">
                <hr>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
            <div class="col-md-10 text-right">
                SubTotal:
            </div>        
            <div id="subTotal" name="subTotal" class="col-md-2 text-right">
                $<?php echo e(number_format($cart->sub_total, 2)); ?>

            </div>
        </div>    
        <div class="row">
            <div class="col-md-10 text-right">
                Discount:
            </div>        
            <div id="discountAmount" name="discountAmount" class="col-md-2 text-right">
                $<?php echo e(number_format($cart->discount_amount, 2)); ?>

            </div>
        </div>
        <div class="row">
            <div class="col-md-10 text-right">
                Total:
            </div>        
            <div id="total" name="total" class="col-md-2 text-right">
                $<?php echo e(number_format($cart->total, 2)); ?>

            </div>
        </div>
   <?php endif; ?>

 <?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    $(document).ready(function() {
        var oldQuantity;
        <?php $__currentLoopData = $cart_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            $('#quantity_<?php echo e($cart_detail->item_id); ?>')
                .on('focus', function () {
                    oldQuantity = this.value;
                })
                .on('change', function () {
                    //var oldSubTotal = Number($("#subTotal").text().replace(/[^0-9\.]+/g,""));
                    //var oldTotal = Number($("#total").text().replace(/[^0-9\.]+/g,""));

                    var cartDetailId = "<?php echo e($cart_detail->id); ?>"
                    var quantity  = $("#quantity_<?php echo e($cart_detail->item_id); ?> option:selected").val();
                    var sendingData ={ cart_detail_id : cartDetailId, quantity : quantity };
                
                    $.post("/api/v1/cart", sendingData)
                        .done(function(data) {                            
                            var jsonData = $.parseJSON(data);
                            var newTotal = jsonData.total;
                            var newSubTotal = jsonData.sub_total;
                                                   
                            var cartDetails = [];
                            cartDetails = jsonData.cart_details;
                            if (cartDetails.length == 0) {
                                location.replace('<?php echo e(route('cart')); ?>');
                            }
                            else {
                                if (quantity == 0) {
                                    $('#item_<?php echo e($cart_detail->item_id); ?>').remove();
                                }
                                else {
                                    for (i = 0; i < cartDetails.length; i++) {
                                        if (cartDetails[i].item_id == <?php echo e($cart_detail->item_id); ?>) {
                                            newItemSubTotal = cartDetails[i].price * cartDetails[i].quantity;
                                            $('#itemSubTotal_<?php echo e($cart_detail->item_id); ?>').text('$' + newItemSubTotal.toFixed(2));
                                            break;
                                        }
                                    }
                                }
                                $('#subTotal').text('$' + newSubTotal.toFixed(2));
                                $('#total').text('$' + newTotal.toFixed(2)); 
                            }
                            
                        });
                });
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    });
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>