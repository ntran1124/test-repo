<nav class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li><a href="<?php echo e(route('items.index')); ?>">Home</a></li>
        <?php if(Auth::check()): ?> 
          <li><a href="<?php echo e(route('logout')); ?>">Log out</a></li>
        <?php else: ?>
          <li><a href="<?php echo e(route('login')); ?>">Log in</a></li>
        <?php endif; ?>
        <li><a href="<?php echo e(route('departments.index')); ?>">Department management</a></li>
        <li><a href="<?php echo e(route('categories.index')); ?>">Category management</a></li>
        <li><a href="<?php echo e(route('items.index')); ?>">Item management</a></li>
        <li><a href="<?php echo e(route('manufacturers.index')); ?>">Manufacuter management</a></li>
        <li><a href="<?php echo e(route('suppliers.index')); ?>">Supplier management</a></li>
      </ul>     
      
      
       
      

    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>