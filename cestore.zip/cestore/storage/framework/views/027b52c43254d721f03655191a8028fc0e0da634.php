

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php if(Session::has('info')): ?>
            <div class="row">
                <div class="col-md-12">
                    <p class="alert alert-info"><?php echo e(Session::get('info')); ?></p>
                </div>
            </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <h1><?php echo e($item->name); ?></h1>

            <div class="col-md-12"> <img src="<?php echo e($item->image_src); ?>" width="200px"></div>
            <div class="col-md-12">
                <h2>Product Details</h2>
                <h4>Manufactured by: <?php echo e($item->manufacturer->name); ?> </h4>
                <p><?php echo e($item->description); ?></p>
            </div>
            <div class="col-md-12">
                <form action="<?php echo e(route('cart')); ?>" method="post">
                    <input type="hidden" name="item_id" value="<?php echo e($item->id); ?>">
                    <?php echo e(csrf_field()); ?>

                    <input type="submit" class="btn btn-success pull-right" value="Add to Cart 2">
                </form>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <h4>Rated: <?php echo e($average); ?> out of 5!!! <br>
                <?php echo e($customersRated); ?> customer(s) rated this item
            </h4>

            <form action="<?php echo e(route('rates')); ?>" method="post">               
                
                <div class="form-group">
                    <label for="code" class="col-md-2">Rate This Item</label>
                    <div class="col-md-10">
                    
                        <?php $__currentLoopData = range(1,5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                         <?php if($i === $rating): ?>
                            <input type ="radio" name="rating" value=<?php echo e($i); ?> checked >        
                                <?php else: ?>
                                    <input type ="radio" name="rating" value=<?php echo e($i); ?> >
                        <?php endif; ?>
                             <?php echo e($i); ?>

                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>         

                    </div>
                </div>
                
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="id" value="<?php echo e($item->id); ?>">

                <div class="col-md-10 col-md-offset-2">
                    </br>
                    <a href="<?php echo e(route('display')); ?>" class="link">Back to items</a>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    
                    <input type="submit" value="Rate">

                    </br></br>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>