<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-md-12">
            <form action="<?php echo e(route('suppliers.create')); ?>" method="post">
                <div class="form-group">
                    <label for="name" class="col-md-2">Name</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="name" name="name" placeholder="Supplier's Name">
                    </div>
                </div>

                <div class="form-group">
                    <label for="is_direct_sales" class="col-md-2">Direct Sales</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="is_direct_sales" name="is_direct_sales" placeholder="1 or 0">
                    </div>
                </div>

                <div class="form-group">
                    <label for="contact_name" class="col-md-2">Contact Name</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="contact_name" name="contact_name" placeholder="Jane Smith">
                    </div>
                </div>

                <div class="form-group">
                    <label for="contact_title" class="col-md-2">Contact Title</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="contact_title" name="contact_title" placeholder="Purchaser">
                    </div>
                </div>

                <div class="form-group">
                    <label for="phone" class="col-md-2">Phone Number</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="phone" name="phone" placeholder="(555)555-5555">
                    </div>
                </div>

                <div class="form-group">
                    <label for="fax" class="col-md-2">Fax Number</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="fax" name="fax" placeholder="(555)555-5555">
                    </div>
                </div>

                <div class="form-group">
                    <label for="email" class="col-md-2">Email Address</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="email" name="email" placeholder="email@gmail.com">
                    </div>
                </div>

                <div class="form-group">
                    <label for="homepage" class="col-md-2">Homepage</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="homepage" name="homepage" placeholder="www.example.com">
                    </div>
                </div>

                <div class="form-group">
                    <label for="address" class="col-md-2">Mailing Address</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="address" name="address">
                    </div>
                </div>

                <?php echo e(csrf_field()); ?>

                <div class="col-md-10 col-md-offset-2">
                <div class=row> <br> </div>
                    <button type="submit" class="btn btn-primary">Create</button> 
                    <a href="<?php echo e(route('suppliers.index')); ?>" class="btn btn-primary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>