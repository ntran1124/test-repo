<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/cart', [
    'uses' => 'CartController@index',
    'as' => 'cart'
]);
Route::post('/cart', [
    'uses' => 'CartController@postItem',
    'as' => 'cart'
]);

Route::get('/display', [
    'uses' => 'ItemListingController@getDisplay',
    'as' => 'display'
]);

    Route::post('/display', [
    'uses' => 'ItemListingController@postAddToCart',
    'as' => 'display'
]);

Route::get('/itemdetail/{id}', [
    'uses' => 'ItemListingController@getDetail',
    'as' => 'itemdetail'
]);

Route::post('/rates', [
    'uses' => 'ItemListingController@postRate',
    'as' => 'rates'
])->middleware('auth');



Auth::routes();

Route::get('logout', [
    'uses' => 'Auth\LogoutController@logout',
    'as' => 'logout'
]);

Route::group(['prefix' => 'items'], function() {
    Route::get('', [
        'uses' => 'ItemsController@getIndex',
        'as' => 'items.index'
    ]);
});

Route::group(['prefix' => 'departments'], function() {
    Route::get('', [
        'uses' => 'DepartmentsController@getIndex',
        'as' => 'departments.index'
    ])->middleware('auth');

    Route::get('create', [
        'uses' => 'DepartmentsController@getCreate',
        'as' => 'departments.create'
    ])->middleware('auth');

    Route::post('create', [
        'uses' => 'DepartmentsController@postCreate',
        'as' => 'departments.create'
    ])->middleware('auth');

    Route::get('update/{id}', [
        'uses' => 'DepartmentsController@getUpdate',
        'as' => 'departments.update'
    ])->middleware('auth');

    Route::post('update', [
        'uses' => 'DepartmentsController@postUpdate',
        'as' => 'departments.updateDepartment'
    ])->middleware('auth');

    Route::get('delete/{id}', [
        'uses' => 'DepartmentsController@getDelete',
        'as' => 'departments.delete'
    ])->middleware('auth');

    Route::post('delete', [
        'uses' => 'DepartmentsController@postDelete',
        'as' => 'departments.deleteDepartment'
    ])->middleware('auth');
});

Route::group(['prefix' => 'categories'], function() {
    Route::get('', [
        'uses' => 'CategoriesController@getIndex',
        'as' => 'categories.index'
    ])->middleware('auth');
    
    Route::get('detail/{id}', [
        'uses' => 'CategoriesController@getDetail',
        'as' => 'categories.detail'
    ])->middleware('auth');

    Route::get('create', [
        'uses' => 'CategoriesController@getCreate',
        'as' => 'categories.create'
    ])->middleware('auth');

    Route::post('create', [
        'uses' => 'CategoriesController@postCreate',
        'as' => 'categories.create'
    ])->middleware('auth');

    Route::get('update/{id}', [
        'uses' => 'CategoriesController@getUpdate',
        'as' => 'categories.update'
    ])->middleware('auth');

    Route::post('update', [
        'uses' => 'CategoriesController@postUpdate',
        'as' => 'categories.updateCategory'
    ])->middleware('auth');

    Route::get('delete/{id}', [
        'uses' => 'CategoriesController@getDelete',
        'as' => 'categories.delete'
    ])->middleware('auth');

    Route::post('delete', [
        'uses' => 'CategoriesController@postDelete',
        'as' => 'categories.deleteCategory'
    ])->middleware('auth');
});

Route::group(['prefix' => 'items'], function() {
    Route::get('', [
        'uses' => 'ItemsController@getIndex',
        'as' => 'items.index'
    ])->middleware('auth');
    
    Route::get('detail/{id}', [
        'uses' => 'ItemsController@getDetail',
        'as' => 'items.detail'
    ])->middleware('auth');

    Route::get('create', [
        'uses' => 'ItemsController@getCreate',
        'as' => 'items.create'
    ])->middleware('auth');

    Route::post('create', [
        'uses' => 'ItemsController@postCreate',
        'as' => 'items.create'
    ])->middleware('auth');

    Route::get('update/{id}', [
        'uses' => 'ItemsController@getUpdate',
        'as' => 'items.update'
    ])->middleware('auth');

    Route::post('update', [
        'uses' => 'ItemsController@postUpdate',
        'as' => 'items.updateItem'
    ])->middleware('auth');

    Route::get('delete/{id}', [
        'uses' => 'ItemsController@getDelete',
        'as' => 'items.delete'
    ])->middleware('auth');

    Route::post('delete', [
        'uses' => 'ItemsController@postDelete',
        'as' => 'items.deleteItem'
    ])->middleware('auth');

    // Route::get('setprice/{id}', [
    //     'uses' => 'ItemsController@getSetPrice',
    //     'as' => 'items.setprice'
    // ])->middleware('auth');

    // Route::post('setprice', [
    //     'uses' => 'ItemsController@postSetPrice',
    //     'as' => 'items.setpricetoitem'
    // ])->middleware('auth');
});

//Defining the manufactureres routes

Route::group(['prefix' => 'manufacturers'], function() {
    Route::get('', [
        'uses' => 'ManufacturersController@getIndex',
        'as' => 'manufacturers.index'              
    ])->middleware('auth');

    Route::get('create', [
        'uses' => 'ManufacturersController@getCreate',
        'as' => 'manufacturers.create'
    ])->middleware('auth');

    Route::post('create', [
        'uses' => 'ManufacturersController@postCreate',
        'as' => 'manufacturers.create'
    ])->middleware('auth');

    Route::get('update/{id}', [
        'uses' => 'ManufacturersController@getUpdate',
        'as' => 'manufacturers.update'
    ])->middleware('auth');

    Route::post('update', [
        'uses' => 'ManufacturersController@postUpdate',
        'as' => 'manufacturers.updateManufacturer'
    ])->middleware('auth');

    Route::get('delete/{id}', [
        'uses' => 'ManufacturersController@getDelete',
        'as' => 'manufacturers.delete'
    ])->middleware('auth');

    Route::post('delete', [
        'uses' => 'ManufacturersController@postDelete',
        'as' => 'manufacturers.deleteManufacturer'
    ])->middleware('auth');

    Route::get('detail/{id}', [
        'uses' => 'ManufacturersController@getDetail',
        'as' => 'manufacturers.detail'
    ])->middleware('auth');
});

Route::group(['prefix' => 'suppliers'], function() {
    Route::get('', [
        'uses' => 'SuppliersController@getIndex',
        'as' => 'suppliers.index'              
    ])->middleware('auth');

    Route::get('detail/{id}', [
        'uses' => 'SuppliersController@getDetail',
        'as' => 'suppliers.detail'
    ])->middleware('auth');

    Route::get('update/{id}', [
        'uses' => 'SuppliersController@getUpdate',
        'as' => 'suppliers.update'
    ])->middleware('auth');

    Route::post('update', [
        'uses' => 'SuppliersController@postUpdate',
        'as' => 'suppliers.updateSupplier'
    ])->middleware('auth');

    Route::get('delete/{id}', [
        'uses' => 'SuppliersController@getDelete',
        'as' => 'suppliers.delete'
    ])->middleware('auth');

    Route::post('delete', [
        'uses' => 'SuppliersController@postDelete',
        'as' => 'suppliers.deleteSupplier'
    ])->middleware('auth');

    Route::get('create', [
        'uses' => 'SuppliersController@getCreate',
        'as' => 'suppliers.create'
    ])->middleware('auth');

    Route::post('create', [
        'uses' => 'SuppliersController@postCreate',
        'as' => 'suppliers.create'
    ])->middleware('auth');

    
});