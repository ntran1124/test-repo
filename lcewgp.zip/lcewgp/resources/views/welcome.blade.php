@extends('layouts.master')

@section('content')
<h1>Welcome to EC Store</h1>
@endsection