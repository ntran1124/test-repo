<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <p class="alert alert-info">You are deleting the following department.
                <br>If you are sure, click Delete button.
                <br>Otherwise, click Cancel button.
            </p>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <form action="<?php echo e(route('departments.deleteDepartment')); ?>" method="post">
                <div class="form-group">
                    <label for="name" class="col-md-2">Name</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="name" name="name" 
                            value="<?php echo e($department->name); ?>" enabled="false">
                    </div>
                </div>
                <div class="form-group">
                    <label for="description" class="col-md-2">Description</label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" id="description" name="description"
                            value="<?php echo e($department->description); ?>" enabled="false">
                    </div>
                </div>
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="id" value="<?php echo e($department->id); ?>">
                <div class="col-md-10 col-md-offset-2">
                    <button type="submit" class="btn btn-primary">Delete</button> 
                    <a href="<?php echo e(route("departments.index")); ?>" class="btn btn-primary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>